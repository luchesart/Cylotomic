# Real critical points of cyclotomic polynomials via vanishing moments

Lean 4 companion to the preprint by Latchezar P. Tomov. The project uses mathlib's `Polynomial.cyclotomic n ℝ`. Negative and positive counts refer to real zeros of its derivative. The main lower bound counts distinct zeros of odd multiplicity. The exact totals for the two numerical examples count real zeros with multiplicity.

## Build

Install Lean through elan, then run the following commands in this directory. The first command obtains the mathlib cache for the pinned revision. Lake reads the supplied toolchain and package manifest.

```sh
lake exe cache get
lake build
lake env lean Audit.lean
```

The toolchain is Lean 4.19.0. The mathlib revision is `c44e0c8ee63ca166450922a373c7409c5d26b00b`. The Lake configuration includes the larger Lean thread stack used to check the long coefficient lists. The project relies on Lean's kernel to check the finite arithmetic in those certificates.

## Read the proofs

Open [the proof map and numerical explorer](index.html) in a modern browser. It is a self-contained file. Select a result to see its statement, the argument in the preprint, and the corresponding Lean declaration and proof. In the numerical explorer, choose an index, select a root interval to zoom in, and run the exact check. The plot uses floating-point values. The sign and root-count checks use integers.

| Preprint | Principal Lean declaration |
| --- | --- |
| Theorem 1. Signed lower bounds | `Cyclo.signed_lower_bounds`, `Cyclo.card_real_roots_lower_bound` |
| Lemma 2. Logarithmic difference identity and multiplicity in the chart | `Cyclo.slope_prime_list`, `Cyclo.slope_order_eq_rootMultiplicity` |
| Lemma 3. Cancellation against polynomial tests | `Cyclo.integral_iterDelta_eq_zero` |
| Lemma 4. Orthogonality forces sign changes | `Cyclo.sign_changes_of_orthogonality` |
| Lemma 5. The two kernel estimates | `Cyclo.kernelNeg_integrable_moment`, `Cyclo.kernelPos_diff_integrable_moment` |
| Theorem 6. Two negative critical points and one positive critical point, all simple | `Cyclo.Binary.binary_exact` |
| Corollary 7. Prime-power lifts, including multiplicity at zero | `Cyclo.Lifts.prime_power_family` |
| Proposition 8. Exact counts at 885 and 1239 | `Cyclo.critical885_exact`, `Cyclo.critical1239_exact` |

The proof of Theorem 1 in Lean applies a polynomial test built from the actual odd-multiplicity roots of the derivative after a change of coordinates. The general sign-change lemma in the paper also has its own Lean proof. In Theorem 6 and Proposition 8 the written proof uses Descartes' rule. The formal proof obtains the required upper bounds by Rolle's theorem applied to exponential sums with the same coefficient sign patterns. The dyadic brackets furnish the lower bounds for Proposition 8.

`Audit.lean` inspects the transitive axiom dependencies of every public theorem in the project namespace and fails if it finds an axiom outside `propext`, `Classical.choice` and `Quot.sound`. [Audit output](verification/axioms.txt).
