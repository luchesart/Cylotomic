import Cyclo.Signed
import Cyclo.Oscillation
import Cyclo.Lifts
import Cyclo.CertifiedCounts
import Cyclo.ChartOrder

/-! Signed bounds, exact two-prime counts, exponent lifts, and the certified
monotonicity counterexample for real critical points of cyclotomic polynomials. -/
