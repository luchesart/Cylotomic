import Mathlib.Analysis.SpecialFunctions.Gaussian.GaussianIntegral
import Mathlib.Tactic

/-! # The two real logarithmic cyclotomic kernels

For the negative arc the kernel itself has all absolute polynomial moments.
For the positive arc one first subtracts a translate. The two estimates at
each end are uniform in the log-coordinate and are sufficient for all moments.
-/
noncomputable section
open MeasureTheory Real Set Filter

namespace Cyclo

/-- Kernel for the negative real arc, in log-coordinate. -/
def kernelNeg (u : ℝ) : ℝ := -exp u / (exp (exp u) + 1)

/-- Kernel for the positive real arc, in log-coordinate. -/
def kernelPos (u : ℝ) : ℝ := exp u / (exp (exp u) - 1)

private theorem den_pos (u : ℝ) : 0 < exp (exp u) - 1 := by
  exact sub_pos.mpr (Real.one_lt_exp_iff.mpr (exp_pos u))

theorem continuous_kernelNeg : Continuous kernelNeg := by
  unfold kernelNeg
  exact continuous_exp.neg.div ((continuous_exp.comp continuous_exp).add continuous_const)
    (fun u => by positivity)

theorem continuous_kernelPos : Continuous kernelPos := by
  unfold kernelPos
  exact continuous_exp.div ((continuous_exp.comp continuous_exp).sub continuous_const)
    (fun u => (den_pos u).ne')

/-- Left-hand cancellation at the positive arc replaces its limiting constant 1. -/
theorem kernelPos_sub_one_bound (u : ℝ) : |kernelPos u - 1| ≤ exp u := by
  let t := exp u
  have ht : 0 < t := exp_pos _
  have hd : 0 < exp t - 1 := den_pos u
  have h_upper : t / (exp t - 1) ≤ 1 := by
    rw [div_le_iff₀ hd]
    linarith [Real.add_one_le_exp t]
  have hlower := Real.add_one_le_exp (-t)
  rw [exp_neg] at hlower
  have h := mul_le_mul_of_nonneg_right hlower (exp_pos t).le
  rw [inv_mul_cancel₀ (exp_pos t).ne'] at h
  change |t / (exp t - 1) - 1| ≤ t
  rw [abs_of_nonpos (sub_nonpos.mpr h_upper)]
  have h_aux : 1 - t ≤ t / (exp t - 1) := by
    rw [le_div_iff₀ hd]
    nlinarith
  linarith

/-- A simple bound at the right end suffices for every polynomial in the log-coordinate. -/
theorem kernelPos_right_bound (u : ℝ) : |kernelPos u| ≤ 2 * exp (-u) := by
  let t := exp u
  have ht : 0 < t := exp_pos _
  have hd : 0 < exp t - 1 := den_pos u
  change |t / (exp t - 1)| ≤ 2 * exp (-u)
  rw [abs_of_pos (div_pos ht hd), exp_neg, ← div_eq_mul_inv]
  change t / (exp t - 1) ≤ 2 / t
  rw [div_le_div_iff₀ hd ht]
  nlinarith [quadratic_le_exp_of_nonneg ht.le]

theorem kernelNeg_left_bound (u : ℝ) : |kernelNeg u| ≤ exp u := by
  unfold kernelNeg
  rw [neg_div, abs_neg, abs_of_pos (by positivity), div_le_iff₀ (by positivity)]
  nlinarith [mul_nonneg (exp_pos u).le (exp_pos (exp u)).le]

theorem kernelNeg_right_bound (u : ℝ) : |kernelNeg u| ≤ 2 * exp (-u) := by
  apply le_trans _ (kernelPos_right_bound u)
  unfold kernelNeg kernelPos
  rw [neg_div, abs_neg, abs_of_pos (by positivity), abs_of_pos (div_pos (exp_pos _) (den_pos _))]
  exact div_le_div_of_nonneg_left (exp_pos u).le (den_pos u) (by linarith)

private theorem integrable_pow_exp_bound (m : ℕ) {g : ℝ → ℝ} (hg : Continuous g)
    {c : ℝ} (h : ∀ u > 0, |g u| ≤ c * exp (-u)) :
    IntegrableOn (fun u : ℝ => u ^ m * g u) (Ioi 0) := by
  have hin : IntegrableOn (fun u : ℝ => u ^ m * exp (-u)) (Ioi 0) := by
    simpa using integrableOn_rpow_mul_exp_neg_rpow (s := (m : ℝ)) (p := 1)
      (by exact lt_of_lt_of_le (by norm_num) (Nat.cast_nonneg m)) (by norm_num)
  apply (hin.const_mul c).mono' ((continuous_id.pow m).mul hg).aestronglyMeasurable
  apply (ae_restrict_iff' measurableSet_Ioi).mpr
  filter_upwards with u hu
  have hu' : 0 < u := hu
  change |u ^ m * g u| ≤ c * (u ^ m * exp (-u))
  rw [abs_mul, abs_pow, abs_of_pos hu']
  calc u ^ m * |g u| ≤ u ^ m * (c * exp (-u)) :=
          mul_le_mul_of_nonneg_left (h u hu') (pow_nonneg hu'.le _)
       _ = _ := by ring

/-- Exponential bounds at both infinities give all absolute polynomial moments. -/
theorem integrable_moment_of_two_exp_bounds {f : ℝ → ℝ} (hf : Continuous f) (m : ℕ)
    {l r : ℝ} (hl : ∀ u : ℝ, |f u| ≤ l * exp u)
    (hr : ∀ u : ℝ, |f u| ≤ r * exp (-u)) :
    Integrable (fun u : ℝ => u ^ m * f u) := by
  rw [← integrableOn_univ, ← @Iio_union_Ici _ _ (0 : ℝ), integrableOn_union,
    integrableOn_Ici_iff_integrableOn_Ioi]
  refine ⟨?_, integrable_pow_exp_bound m hf (fun u _ => hr u)⟩
  have hpos : IntegrableOn (fun u : ℝ => u ^ m * f (-u)) (Ioi (- (0 : ℝ))) := by
    simpa using integrable_pow_exp_bound m (hf.comp continuous_neg) (c := l) (fun u _ => hl (-u))
  have hneg := hpos.comp_neg_Iio
  apply (hneg.const_mul ((-1 : ℝ) ^ m)).congr
  filter_upwards with u
  change (-1 : ℝ)^m * ((-u)^m * f (- -u)) = u^m * f u
  rw [neg_neg, ← mul_assoc, ← mul_pow, neg_one_mul, neg_neg]

theorem kernelNeg_integrable_moment (m : ℕ) :
    Integrable (fun u : ℝ => u ^ m * kernelNeg u) :=
  integrable_moment_of_two_exp_bounds continuous_kernelNeg m
    (l := 1) (fun u => by simpa using kernelNeg_left_bound u) kernelNeg_right_bound

theorem kernelPos_diff_integrable_moment (a : ℝ) (m : ℕ) :
    Integrable (fun u : ℝ => u ^ m * (kernelPos (u+a) - kernelPos u)) := by
  apply integrable_moment_of_two_exp_bounds
    ((continuous_kernelPos.comp (continuous_id.add continuous_const)).sub continuous_kernelPos) m
    (l := exp a + 1) (r := 2 * (exp (-a) + 1))
  · intro u
    calc |kernelPos (u+a) - kernelPos u| ≤ |kernelPos (u+a) - 1| + |1 - kernelPos u| :=
           abs_sub_le _ 1 _
         _ ≤ exp (u+a) + exp u := by
           rw [abs_sub_comm 1 (kernelPos u)]
           exact add_le_add (kernelPos_sub_one_bound _) (kernelPos_sub_one_bound _)
         _ = _ := by rw [exp_add]; ring
  · intro u
    calc |kernelPos (u+a) - kernelPos u| ≤ |kernelPos (u+a)| + |kernelPos u| := abs_sub _ _
         _ ≤ 2 * exp (-(u+a)) + 2 * exp (-u) :=
           add_le_add (kernelPos_right_bound _) (kernelPos_right_bound _)
         _ = _ := by rw [neg_add, exp_add]; ring

/-- Logarithmic derivative of the positive arc's basic Möbius factor. -/
theorem hasDerivAt_log_pos_factor (u : ℝ) :
    HasDerivAt (fun v : ℝ => log (1 - exp (-exp v))) (kernelPos u) u := by
  have hsmall : exp (-exp u) < 1 := Real.exp_lt_one_iff.mpr (neg_neg_of_pos (exp_pos u))
  have hp := ((hasDerivAt_const u (1 : ℝ)).sub (hasDerivAt_exp u).neg.exp).log
    (by exact (sub_pos.mpr hsmall).ne')
  convert hp using 1
  unfold kernelPos
  rw [exp_neg]
  have he : exp (exp u) ≠ 0 := (exp_pos _).ne'
  have hd := (den_pos u).ne'
  have hi : 1 - (exp (exp u))⁻¹ ≠ 0 := by
    simpa [exp_neg] using (sub_pos.mpr hsmall).ne'
  field_simp

/-- Logarithmic derivative of the negative arc's basic Möbius factor. -/
theorem hasDerivAt_log_neg_factor (u : ℝ) :
    HasDerivAt (fun v : ℝ => log (1 + exp (-exp v))) (kernelNeg u) u := by
  have hp := ((hasDerivAt_const u (1 : ℝ)).add (hasDerivAt_exp u).neg.exp).log
    (by positivity)
  convert hp using 1
  unfold kernelNeg
  rw [exp_neg]
  have he : exp (exp u) ≠ 0 := (exp_pos _).ne'
  have hd : exp (exp u) + 1 ≠ 0 := by positivity
  have hi : 1 + (exp (exp u))⁻¹ ≠ 0 := by positivity
  field_simp
  ring

end Cyclo
