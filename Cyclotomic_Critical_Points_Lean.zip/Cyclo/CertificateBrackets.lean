import Cyclo.CertificateValues
namespace Cyclo.Cert
open Polynomial
set_option maxRecDepth 100000
set_option maxHeartbeats 0

def brackets_885_neg : List ℤ := [-1023, -1009, -957, -934, -445]

theorem signs_885_neg (h : ℤ) (hh : h ∈ brackets_885_neg) :
    (cyclotomic 885 ℝ).derivative.eval ((h:ℝ)/1024) *
      (cyclotomic 885 ℝ).derivative.eval (((h:ℝ)+1)/1024) < 0 := by
  have H : brackets_885_neg.all (fun a => bracket D_885 a 1024) = true := by rfl
  rw [List.all_eq_true] at H
  simp only [derivative_885_eval]
  exact bracket_sound D_885 h 1024 (by decide) (H h hh)

def brackets_885_pos : List ℤ := [685, 1017]

theorem signs_885_pos (h : ℤ) (hh : h ∈ brackets_885_pos) :
    (cyclotomic 885 ℝ).derivative.eval ((h:ℝ)/1024) *
      (cyclotomic 885 ℝ).derivative.eval (((h:ℝ)+1)/1024) < 0 := by
  have H : brackets_885_pos.all (fun a => bracket D_885 a 1024) = true := by rfl
  rw [List.all_eq_true] at H
  simp only [derivative_885_eval]
  exact bracket_sound D_885 h 1024 (by decide) (H h hh)

def brackets_1239_neg : List ℤ := [-1023, -1009, -483]

theorem signs_1239_neg (h : ℤ) (hh : h ∈ brackets_1239_neg) :
    (cyclotomic 1239 ℝ).derivative.eval ((h:ℝ)/1024) *
      (cyclotomic 1239 ℝ).derivative.eval (((h:ℝ)+1)/1024) < 0 := by
  have H : brackets_1239_neg.all (fun a => bracket D_1239 a 1024) = true := by rfl
  rw [List.all_eq_true] at H
  simp only [derivative_1239_eval]
  exact bracket_sound D_1239 h 1024 (by decide) (H h hh)

def brackets_1239_pos : List ℤ := [740, 1018]

theorem signs_1239_pos (h : ℤ) (hh : h ∈ brackets_1239_pos) :
    (cyclotomic 1239 ℝ).derivative.eval ((h:ℝ)/1024) *
      (cyclotomic 1239 ℝ).derivative.eval (((h:ℝ)+1)/1024) < 0 := by
  have H : brackets_1239_pos.all (fun a => bracket D_1239 a 1024) = true := by rfl
  rw [List.all_eq_true] at H
  simp only [derivative_1239_eval]
  exact bracket_sound D_1239 h 1024 (by decide) (H h hh)

end Cyclo.Cert
