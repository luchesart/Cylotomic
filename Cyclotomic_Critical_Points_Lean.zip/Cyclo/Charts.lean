import Cyclo.RolleBounds
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Analysis.Calculus.Deriv.Polynomial
import Mathlib.Algebra.Polynomial.FieldDivision
import Mathlib.Tactic

/-! Pulling exact root bounds and simplicity back from real logarithmic charts. -/
namespace Cyclo
open Set Polynomial

/-- Pick distinct preimages for every element of a finite subset of a chart. -/
private theorem pick_preimages {I J : Set ℝ} {c : ℝ → ℝ} (hs : SurjOn c J I)
    (T : Finset ℝ) (ht : ∀ x ∈ T, x ∈ I) :
    ∃ U : Finset ℝ, U.card = T.card ∧ ∀ u ∈ U, u ∈ J ∧ c u ∈ T := by
  classical
  let r : ℝ → ℝ := fun x => if hx : x ∈ I then (hs hx).choose else 0
  have hr {x : ℝ} (hx : x ∈ T) : r x ∈ J ∧ c (r x) = x := by
    simpa only [r, dif_pos (ht x hx)] using (hs (ht x hx)).choose_spec
  refine ⟨T.image r, Finset.card_image_iff.mpr ?_, ?_⟩
  · intro x hx y hy he
    simpa only [(hr hx).2, (hr hy).2] using congrArg c he
  · intro u hu
    obtain ⟨x,hx,rfl⟩ := Finset.mem_image.mp hu
    exact ⟨(hr hx).1, by rw [(hr hx).2]; exact hx⟩

/-- A bound for distinct roots descends along a surjection of the chosen domains. -/
theorem rootCap_of_surjOn {I J : Set ℝ} {c f : ℝ → ℝ} {k : ℕ}
    (hs : SurjOn c J I) (cap : RootCap J (fun u => f (c u)) k) : RootCap I f k := by
  intro t ht
  obtain ⟨u,hu,h⟩ := pick_preimages hs t (fun x hx => (ht x hx).1)
  rw [← hu]
  exact cap u (fun x hx => ⟨(h x hx).1, (ht _ (h x hx).2).2⟩)

/-- Multiplying by a weight may introduce additional zeros; every zero under
consideration still lifts to a zero of the weighted function. -/
theorem rootCap_of_weighted_chart {I J : Set ℝ} {c f w : ℝ → ℝ} {k : ℕ}
    (hs : SurjOn c J I) (cap : RootCap J (fun u => w u * f (c u)) k) : RootCap I f k := by
  apply rootCap_of_surjOn hs
  intro t ht
  apply cap t
  intro x hx
  obtain ⟨hj, hz⟩ := ht x hx
  change f (c x) = 0 at hz
  exact ⟨hj, by change w x * f (c x) = 0; rw [hz, mul_zero]⟩

/-- The positive and negative homographies in the Descartes certificate. -/
noncomputable def logisticChart (s u : ℝ) : ℝ := s * Real.exp u / (1 + Real.exp u)

def signedUnitInterval (s : ℝ) : Set ℝ :=
  if s = 1 then Ioo 0 1 else Ioo (-1) 0

theorem logisticChart_differentiableAt (s u : ℝ) :
    DifferentiableAt ℝ (logisticChart s) u := by
  unfold logisticChart
  fun_prop (disch := positivity)

theorem logisticChart_surjOn {s : ℝ} (hs : s = 1 ∨ s = -1) :
    SurjOn (logisticChart s) univ (signedUnitInterval s) := by
  intro x hx
  rcases hs with rfl | rfl
  · have h : 0 < x ∧ x < 1 := by simpa [signedUnitInterval] using hx
    have hp : 0 < 1-x := sub_pos.mpr h.2
    refine ⟨Real.log (x/(1-x)), mem_univ _, ?_⟩
    simp only [logisticChart, Real.exp_log (div_pos h.1 hp), one_mul]
    field_simp
  · have hne : (-1 : ℝ) ≠ 1 := by norm_num
    have h : -1 < x ∧ x < 0 := by simpa [signedUnitInterval, hne] using hx
    have hp : 0 < 1+x := by linarith
    refine ⟨Real.log (-x/(1+x)), mem_univ _, ?_⟩
    simp only [logisticChart, Real.exp_log (div_pos (neg_pos.mpr h.2) hp)]
    field_simp

/-- A list of distinct interval roots gives equally many chart witnesses. -/
theorem chart_witnesses {s : ℝ} (hs : s = 1 ∨ s = -1) (D : ℝ[X]) (T : Finset ℝ)
    (hT : ∀ x ∈ T, x ∈ signedUnitInterval s ∧ D.eval x = 0) :
    ∃ U : Finset ℝ, U.card = T.card ∧ ∀ u ∈ U, D.eval (logisticChart s u) = 0 := by
  obtain ⟨U,hu,h⟩ := pick_preimages (logisticChart_surjOn hs) T (fun x hx => (hT x hx).1)
  exact ⟨U,hu,fun u hmem => (hT _ (h u hmem).2).2⟩

theorem rootCap_logisticChart {s : ℝ} (hs : s = 1 ∨ s = -1) (D : ℝ[X]) {k : ℕ}
    (cap : RootCap univ (fun u => D.eval (logisticChart s u)) k) :
    RootCap (signedUnitInterval s) D.eval k :=
  rootCap_of_surjOn (logisticChart_surjOn hs) cap

/-- A simple zero of a weighted composition can only come from a simple
zero of the underlying polynomial. No division by the chart derivative is needed. -/
theorem polynomial_simple_of_weighted_chart (D : ℝ[X]) {c w : ℝ → ℝ} {u : ℝ}
    (hc : DifferentiableAt ℝ c u) (hw : DifferentiableAt ℝ w u)
    (hroot : D.eval (c u) = 0)
    (hs : deriv (fun z => w z * D.eval (c z)) u ≠ 0) :
    D.derivative.eval (c u) ≠ 0 := by
  intro hd
  apply hs
  have hcomp := (D.hasDerivAt (c u)).comp u hc.hasDerivAt
  simpa [Function.comp_def, hroot, hd] using (hw.hasDerivAt.mul hcomp).deriv

theorem rootMultiplicity_one_of_derivative_ne (D : ℝ[X]) {x : ℝ}
    (hx : D.eval x = 0) (hd : D.derivative.eval x ≠ 0) : D.rootMultiplicity x = 1 := by
  have hn : D ≠ 0 := by rintro rfl; simp at hd
  have hr : D.IsRoot x := hx
  have hp := (rootMultiplicity_pos hn).2 hr
  have hzero : D.derivative.rootMultiplicity x = 0 := rootMultiplicity_eq_zero hd
  have hrel := derivative_rootMultiplicity_of_root hr
  omega

/-- Simplicity on every point of the chart gives exact multiplicity on the
entire signed unit interval. -/
theorem simple_on_logistic_interval {s : ℝ} (hs : s = 1 ∨ s = -1) (D : ℝ[X])
    {w : ℝ → ℝ} (hw : Differentiable ℝ w)
    (hsim : ∀ u, D.eval (logisticChart s u) = 0 →
      deriv (fun v => w v * D.eval (logisticChart s v)) u ≠ 0)
    {x : ℝ} (hx : x ∈ signedUnitInterval s) (he : D.eval x = 0) :
    D.rootMultiplicity x = 1 := by
  obtain ⟨u, _, rfl⟩ := logisticChart_surjOn hs hx
  apply rootMultiplicity_one_of_derivative_ne D he
  exact polynomial_simple_of_weighted_chart D (logisticChart_differentiableAt s u) (hw u)
    he (hsim u he)

end Cyclo
