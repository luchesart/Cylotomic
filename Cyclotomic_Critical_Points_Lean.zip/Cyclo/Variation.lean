import Cyclo.RolleBounds
import Mathlib

/-! A finite sign-variation certificate. On the logarithmic axis, multiplying
by an exponential preserves zeros. Differentiating the shifted series then
multiplies its j-th coefficient by j minus the shift. Successive shifts give
an explicit Rolle bound and simplicity when all allowed zeros occur. -/
open Real Set
namespace Cyclo.Cert

def tilt (k n : ℤ) : List ℤ → List ℤ
  | [] => []
  | a :: as => (a*(n-k)) :: tilt k (n+1) as

def applyTilts (A : List ℤ) : List ℤ → List ℤ
  | [] => A
  | k :: ks => applyTilts (tilt k 0 A) ks

noncomputable def series : List ℤ → ℤ → ℝ → ℝ
  | [], _, _ => 0
  | a :: rest, n, u => (a:ℝ)*exp ((n:ℝ)*u) + series rest (n+1) u

private theorem shift (a : List ℤ) (n s : ℤ) (u : ℝ) :
    series a (n-s) u = exp (-(s:ℝ)*u) * series a n u := by
  induction a generalizing n with
  | nil => simp [series]
  | cons x xs ih =>
    simp only [series, mul_add]
    rw [show n-s+1=n+1-s by omega, ih]
    congr 1
    push_cast
    rw [mul_left_comm, ← exp_add]
    congr 2
    ring

private theorem deriv_aux (A : List ℤ) (n k : ℤ) (u : ℝ) :
    HasDerivAt (series A (n-k)) (series (tilt k n A) (n-k) u) u := by
  induction A generalizing n with
  | nil => simpa [series, tilt] using (hasDerivAt_const u (0:ℝ))
  | cons a A ih =>
    have hd := (((hasDerivAt_id u).const_mul ((n:ℝ)-(k:ℝ))).exp.const_mul (a:ℝ)).add (ih (n+1))
    convert hd using 1
    · funext t
      simp [series, add_sub_right_comm, id_eq]
    · simp [series, tilt, add_sub_right_comm, id_eq]
      ring

theorem series_hasDerivAt (A : List ℤ) (k : ℤ) (u : ℝ) :
    HasDerivAt (series A (-k)) (series (tilt k 0 A) (-k) u) u := by
  simpa using deriv_aux A 0 k u

theorem series_hasDerivAt_zero (A : List ℤ) (u : ℝ) :
    HasDerivAt (series A 0) (series (tilt 0 0 A) 0 u) u := by simpa using series_hasDerivAt A 0 u

private theorem series_nonneg (A : List ℤ) (h : ∀ a ∈ A, (0:ℤ) ≤ a) (n : ℤ) (u : ℝ) :
    0 ≤ series A n u := by
  induction A generalizing n with
  | nil => simp [series]
  | cons a A ih =>
    exact add_nonneg (mul_nonneg (by exact_mod_cast h a (by simp)) (exp_pos _).le)
      (ih (fun z hz => h z (by simp [hz])) _)

private theorem series_pos (A : List ℤ) (h : ∀ a ∈ A, (0:ℤ) ≤ a)
    (hp : ∃ a ∈ A, (0:ℤ) < a) (n : ℤ) (u : ℝ) : 0 < series A n u := by
  induction A generalizing n with
  | nil => simp at hp
  | cons a A ih =>
    have hA : ∀ z ∈ A, (0:ℤ) ≤ z := fun z hz => h z (by simp [hz])
    obtain ⟨z,hz,hzpos⟩ := hp
    rcases List.mem_cons.mp hz with rfl | hz
    · exact add_pos_of_pos_of_nonneg (mul_pos (by exact_mod_cast hzpos) (exp_pos _)) (series_nonneg _ hA _ _)
    · exact add_pos_of_nonneg_of_pos (mul_nonneg (by exact_mod_cast h a (by simp)) (exp_pos _).le)
        (ih hA ⟨z,hz,hzpos⟩ _)

private theorem derivative_cap (A : List ℤ) (k : ℤ) {j : ℕ}
    (H : Cyclo.RootCap univ (series (tilt k 0 A) 0) j) :
    Cyclo.RootCap univ (deriv (series A (-k))) j := by
  intro s hs
  apply H s
  intro x hx
  have hd := (hs x hx).2
  rw [(series_hasDerivAt A k x).deriv] at hd
  have he := shift (tilt k 0 A) 0 k x
  simp only [zero_sub] at he
  rw [he] at hd
  exact ⟨mem_univ _, (mul_eq_zero.mp hd).resolve_left (exp_pos _).ne'⟩

/-- A nonnegative nonzero coefficient list after j shifts bounds the number of
distinct positive roots of the unshifted polynomial by j, in log coordinates. -/
theorem cap_of_tilts (A ks : List ℤ) (h : ∀ a ∈ applyTilts A ks, 0 ≤ a)
    (hp : ∃ a ∈ applyTilts A ks, 0 < a) : Cyclo.RootCap univ (series A 0) ks.length := by
  induction ks generalizing A with
  | nil =>
    intro s hs
    have he : s = ∅ := Finset.eq_empty_iff_forall_not_mem.mpr fun x hx =>
      (series_pos A h hp 0 x).ne' (hs x hx).2
    simp [he]
  | cons k ks ih =>
    have H := derivative_cap A k (ih _ h hp)
    have K := Cyclo.rolle_count (I := (univ : Set ℝ)) (inferInstance : (univ : Set ℝ).OrdConnected)
      (f := series A (-k)) (continuous_iff_continuousAt.mpr (fun u => (series_hasDerivAt A k u).continuousAt)).continuousOn H
    intro s hs
    apply K s
    intro x hx
    have he := shift A 0 k x
    simp only [zero_sub] at he
    exact ⟨mem_univ _, by rw [he, (hs x hx).2, mul_zero]⟩

/-- Attainment of the cap makes each corresponding root of the exponential
polynomial simple, by Rolle between adjacent roots and at a hypothetical
multiple root. -/
theorem simple_of_tilts (A : List ℤ) (k : ℤ) (ks : List ℤ)
    (h : ∀ a ∈ applyTilts A (k::ks), 0 ≤ a) (hp : ∃ a ∈ applyTilts A (k::ks), 0 < a)
    (s : Finset ℝ) (hs : ∀ x ∈ s, series A 0 x = 0) (hn : s.card = ks.length+1)
    (x : ℝ) (hx : series A 0 x = 0) : deriv (series A 0) x ≠ 0 := by
  have H := derivative_cap A k (cap_of_tilts (tilt k 0 A) ks h hp)
  have hid (t : ℝ) : series A (-k) t = exp (-(k:ℝ)*t) * series A 0 t := by simpa using shift A 0 k t
  have hc := (continuous_iff_continuousAt.mpr (fun u => (series_hasDerivAt A k u).continuousAt)).continuousOn (s:=univ)
  have hnon := Cyclo.rolle_simple (inferInstance : (univ : Set ℝ).OrdConnected) hc H
    (s := s) (fun t ht => ⟨mem_univ _, by rw [hid,hs t ht,mul_zero]⟩) hn (mem_univ x) (by rw [hid,hx,mul_zero])
  intro hd
  apply hnon
  have e₁ := ((hasDerivAt_id x).const_mul (-(k:ℝ))).exp
  have e₂ := ((series_hasDerivAt_zero A x).differentiableAt.hasDerivAt)
  rw [show series A (-k) = (fun t : ℝ => exp (-(k:ℝ)*t) * series A 0 t) from funext hid]
  simpa [hx, hd, id_eq] using (e₁.mul e₂).deriv

end Cyclo.Cert
