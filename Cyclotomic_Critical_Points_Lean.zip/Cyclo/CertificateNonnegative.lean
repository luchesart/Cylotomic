import Cyclo.Variation
import Cyclo.CertificateData
import Cyclo.CertificateTables

/-! Integer sign checks after successive weighted differentiations. -/
namespace Cyclo.Cert
set_option maxRecDepth 20000
set_option maxHeartbeats 12000000

private theorem allNonnegative {A : List ℤ} (ha : A.all (fun a => decide (0 ≤ a)) = true) :
    ∀ a ∈ A, 0 ≤ a := by simpa [List.all_eq_true] using ha

private theorem somePositive {A : List ℤ} (ha : A.any (fun a => decide (0 < a)) = true) :
    ∃ a ∈ A, 0 < a := by simpa [List.any_eq_true] using ha

theorem tilted_signs_885_neg : (∀ a ∈ applyTilts (scale (-1) Q_885_neg) [202,421,436,459,463], 0 ≤ a) ∧
    (∃ a ∈ applyTilts (scale (-1) Q_885_neg) [202,421,436,459,463], 0 < a) := by
  constructor
  · apply allNonnegative
    decide +kernel
  · apply somePositive
    decide +kernel

theorem tilted_signs_885_pos : (∀ a ∈ applyTilts (scale 1 Q_885_pos) [311,463], 0 ≤ a) ∧
    (∃ a ∈ applyTilts (scale 1 Q_885_pos) [311,463], 0 < a) := by
  constructor
  · apply allNonnegative
    decide +kernel
  · apply somePositive
    decide +kernel

theorem tilted_signs_1239_neg : (∀ a ∈ applyTilts (scale (-1) Q_1239_neg) [328,687,695], 0 ≤ a) ∧
    (∃ a ∈ applyTilts (scale (-1) Q_1239_neg) [328,687,695], 0 < a) := by
  constructor
  · apply allNonnegative
    decide +kernel
  · apply somePositive
    decide +kernel

theorem tilted_signs_1239_pos : (∀ a ∈ applyTilts (scale 1 Q_1239_pos) [504,693], 0 ≤ a) ∧
    (∃ a ∈ applyTilts (scale 1 Q_1239_pos) [504,693], 0 < a) := by
  constructor
  · apply allNonnegative
    decide +kernel
  · apply somePositive
    decide +kernel

end Cyclo.Cert
