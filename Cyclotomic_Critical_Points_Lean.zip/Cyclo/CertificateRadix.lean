import Cyclo.CertificateData

namespace Cyclo.Cert
open Polynomial
def atInt : List ℤ → ℤ → ℤ
  | [], _ => 0
  | a :: l, b => a + b * atInt l b

theorem atInt_cast (l : List ℤ) (b : ℤ) : (atInt l b : ℝ) = horner l b := by
  induction l with
  | nil => simp [atInt,horner]
  | cons a l ih => simp [atInt,horner,ih]

theorem poly_zero_of_radix (b : ℤ) (hb : 0 < b) (l : List ℤ)
    (h : ∀ a ∈ l, |a| < b) (hz : atInt l b = 0) : poly l = 0 := by
  induction l with
  | nil => rfl
  | cons a l ih =>
    change a + b * atInt l b = 0 at hz
    have ha : a = 0 := Int.eq_zero_of_abs_lt_dvd ⟨-atInt l b, by linarith⟩ (h _ (by simp))
    rw [ha, zero_add] at hz
    have ht := (mul_eq_zero.mp hz).resolve_left hb.ne'
    simp [poly,ha,ih (fun x hx => h x (by simp [hx])) ht]

/-- Equality of two bounded integer polynomials can be certified at one radix. -/
theorem eq_of_radix (b : ℤ) (hb : 0 < b) (l r : List ℤ)
    (h : ∀ a ∈ add l (scale (-1) r), |a| < b)
    (hz : horner l b = horner r b) : poly l = poly r := by
  have ha : ((atInt (add l (scale (-1) r)) b : ℤ) : ℝ) = 0 := by
    rw [atInt_cast,horner_add,horner_scale,hz]
    push_cast
    ring
  have H := poly_zero_of_radix b hb _ h (by exact_mod_cast ha)
  rw [poly_add,poly_scale] at H
  apply sub_eq_zero.mp
  simpa [sub_eq_add_neg] using H


/-- A division-free certificate for evaluating a candidate numerator at the chosen radix. -/
theorem homog_at_radix (s b : ℤ) (hb : 0 < b) (D Q : List ℤ) (hD : D ≠ [])
    (he : (1+b) * atInt Q b = (ratPair (s*b) (1+b) D).1) :
    horner Q b = horner (homog s D).1 b := by
  have hb' : 0 < (b:ℝ) := by exact_mod_cast hb
  have hd : (1:ℝ)+b ≠ 0 := by linarith
  have hdi : (1:ℤ)+b ≠ 0 := by omega
  have H := congrArg (fun n : ℤ => (n:ℝ)) he
  simp only [Int.cast_mul, Int.cast_add, Int.cast_one, atInt_cast] at H
  rw [(ratPair_sound (s*b) (1+b) hdi D).1] at H
  push_cast at H
  rw [(horner_homog s D b hd).1]
  have hlen : 1 ≤ D.length := List.length_pos_iff.mpr hD
  have hpow : ((1:ℝ)+b)^D.length = ((1:ℝ)+b) * (1+b)^(D.length-1) := by
    rw [← pow_succ', Nat.sub_add_cancel hlen]
  rw [hpow, mul_assoc] at H
  exact mul_left_cancel₀ hd H

end Cyclo.Cert
