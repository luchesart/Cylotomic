import Cyclo.CertificateValues
import Cyclo.CertificateRadix
import Cyclo.CertificateMass

namespace Cyclo.Cert
open Polynomial
set_option maxRecDepth 100000
set_option maxHeartbeats 0

/-- A single exact evaluation at radix b certifies an entire homogeneous transform.
The inequality bounds the sum of absolute coefficients of the difference strictly below b. -/
theorem check_homog (s b : ℤ) (hs : |s| ≤ 1) (hb : 0 < b) (D Q : List ℤ)
    (hD : D ≠ []) (hsize : mass Q + 2^D.length * mass D < b)
    (he : (1+b) * atInt Q b = (ratPair (s*b) (1+b) D).1)
    (t : ℝ) (ht : 1+t ≠ 0) :
    horner Q t = (1+t)^(D.length-1) * horner D ((s:ℝ)*t/(1+t)) := by
  have hd := homog_mass s hs D
  have hbound := mass_add_le Q (scale (-1) (homog s D).1)
  simp only [mass_scale,abs_neg,abs_one,one_mul] at hbound
  have hcoeff : ∀ a ∈ add Q (scale (-1) (homog s D).1), |a| < b := by
    intro a ha
    exact (abs_le_mass_of_mem ha).trans_lt (lt_of_le_of_lt hbound ((add_le_add_left hd.1 _).trans_lt hsize))
  have hpoly := eq_of_radix b hb Q (homog s D).1 hcoeff (homog_at_radix s b hb D Q hD he)
  have hQ := congrArg (Polynomial.eval t) hpoly
  simp only [eval_poly] at hQ
  exact hQ.trans (horner_homog s D t ht).1

/-- 800 bits exceed the certified coefficient mass on both examples. -/
private abbrev radix : ℤ := 2^800

theorem Q_885_neg_eval (t : ℝ) (ht : 0 < t) :
    horner Q_885_neg t = (1+t)^463 * (cyclotomic 885 ℝ).derivative.eval (-t/(1+t)) := by
  have H := check_homog (-1) radix (by decide) (by decide) D_885 Q_885_neg
    (by decide) (by decide) (by rfl) t (by linarith)
  rw [derivative_885_eval]
  simpa only [show D_885.length-1 = 463 from rfl, Int.cast_neg, Int.cast_one,
    one_mul, neg_one_mul] using H

theorem Q_885_pos_eval (t : ℝ) (ht : 0 < t) :
    horner Q_885_pos t = (1+t)^463 * (cyclotomic 885 ℝ).derivative.eval (t/(1+t)) := by
  have H := check_homog (1) radix (by decide) (by decide) D_885 Q_885_pos
    (by decide) (by decide) (by rfl) t (by linarith)
  rw [derivative_885_eval]
  simpa only [show D_885.length-1 = 463 from rfl, Int.cast_neg, Int.cast_one,
    one_mul, neg_one_mul] using H

theorem Q_1239_neg_eval (t : ℝ) (ht : 0 < t) :
    horner Q_1239_neg t = (1+t)^695 * (cyclotomic 1239 ℝ).derivative.eval (-t/(1+t)) := by
  have H := check_homog (-1) radix (by decide) (by decide) D_1239 Q_1239_neg
    (by decide) (by decide) (by rfl) t (by linarith)
  rw [derivative_1239_eval]
  simpa only [show D_1239.length-1 = 695 from rfl, Int.cast_neg, Int.cast_one,
    one_mul, neg_one_mul] using H

theorem Q_1239_pos_eval (t : ℝ) (ht : 0 < t) :
    horner Q_1239_pos t = (1+t)^695 * (cyclotomic 1239 ℝ).derivative.eval (t/(1+t)) := by
  have H := check_homog (1) radix (by decide) (by decide) D_1239 Q_1239_pos
    (by decide) (by decide) (by rfl) t (by linarith)
  rw [derivative_1239_eval]
  simpa only [show D_1239.length-1 = 695 from rfl, Int.cast_neg, Int.cast_one,
    one_mul, neg_one_mul] using H

end Cyclo.Cert
