import Cyclo.CertificateTables
import Cyclo.CertificateData
namespace Cyclo.Cert
open Polynomial
set_option maxRecDepth 100000
set_option maxHeartbeats 0

theorem phi_1_poly : poly P_1 = cyclotomic 1 ℝ := by
  simp [P_1,poly, cyclotomic_one]
  ring

theorem phi_3_poly : poly P_3 = cyclotomic 3 ℝ := by
  apply prime_step (n := 1) (q := 3) (by decide) (by decide) P_1 P_3 phi_1_poly
  rfl

theorem phi_15_poly : poly P_15 = cyclotomic 15 ℝ := by
  apply prime_step (n := 3) (q := 5) (by decide) (by decide) P_3 P_15 phi_3_poly
  rfl

theorem phi_21_poly : poly P_21 = cyclotomic 21 ℝ := by
  apply prime_step (n := 3) (q := 7) (by decide) (by decide) P_3 P_21 phi_3_poly
  rfl

theorem phi_885_poly : poly P_885 = cyclotomic 885 ℝ := by
  apply prime_step (n := 15) (q := 59) (by decide) (by decide) P_15 P_885 phi_15_poly
  rfl

theorem deriv_885_poly : poly D_885 = (cyclotomic 885 ℝ).derivative := by
  rw [← phi_885_poly]
  exact (show D_885 = weighted 1 P_885.tail by rfl) ▸ poly_derivative P_885.head! P_885.tail

theorem derivative_885_eval (x : ℝ) :
    (cyclotomic 885 ℝ).derivative.eval x = horner D_885 x := by
  rw [← deriv_885_poly,eval_poly]

theorem phi_1239_poly : poly P_1239 = cyclotomic 1239 ℝ := by
  apply prime_step (n := 21) (q := 59) (by decide) (by decide) P_21 P_1239 phi_21_poly
  rfl

theorem deriv_1239_poly : poly D_1239 = (cyclotomic 1239 ℝ).derivative := by
  rw [← phi_1239_poly]
  exact (show D_1239 = weighted 1 P_1239.tail by rfl) ▸ poly_derivative P_1239.head! P_1239.tail

theorem derivative_1239_eval (x : ℝ) :
    (cyclotomic 1239 ℝ).derivative.eval x = horner D_1239 x := by
  rw [← deriv_1239_poly,eval_poly]

end Cyclo.Cert
