import Cyclo.Identity
import Mathlib.Analysis.Analytic.Order
import Mathlib.Analysis.Analytic.Polynomial
import Mathlib

/-! # Exact analytic vanishing order in each signed chart
A chart with nonzero derivative has a simple first-order factor. Pulling back
a polynomial root and multiplying by a nonzero analytic weight preserves its
exact order, including orders greater than one. -/
open Polynomial Filter
open scoped Topology
noncomputable section
namespace Cyclo

theorem analyticAt_coord (s : Bool) (u : ℝ) : AnalyticAt ℝ (coord s) u := by
  cases s <;> unfold coord <;> simp only [if_true, Bool.false_eq_true, if_false] <;> fun_prop

private theorem analytic_poly_coord (P : ℝ[X]) (s : Bool) (u : ℝ) :
    AnalyticAt ℝ (fun v => P.eval (coord s v)) u :=
  (analyticAt_coord s u).aeval_polynomial P

theorem analyticAt_slopeWeight {n : ℕ} (hn : 0 < n) (s : Bool) (u : ℝ) :
    AnalyticAt ℝ (slopeWeight n s) u := by
  exact ((analyticAt_coord s u).neg.mul analyticAt_rexp).div
    (analytic_poly_coord _ s u) (cyclo_eval_ne_zero hn (abs_coord_lt_one s u))

theorem analyticAt_slope {n : ℕ} (hn : 0 < n) (s : Bool) (u : ℝ) :
    AnalyticAt ℝ (slope n s) u := by
  rw [show slope n s = fun v => slopeWeight n s v * (cyclotomic n ℝ).derivative.eval (coord s v)
        from funext (slope_eq_weight_mul hn s)]
  exact (analyticAt_slopeWeight hn s u).mul (analytic_poly_coord _ s u)

private theorem regular_chart_factor {c : ℝ → ℝ} {u : ℝ}
    (hc : AnalyticAt ℝ c u) (hd : deriv c u ≠ 0) :
    ∃ g : ℝ → ℝ, AnalyticAt ℝ g u ∧ g u ≠ 0 ∧
      ∀ᶠ v in 𝓝 u, c v - c u = (v-u)*g v := by
  let F (v : ℝ) := c v - c u
  have hF : AnalyticAt ℝ F u := hc.sub analyticAt_const
  have h1 : (1 : ℕ∞) ≤ hF.order := ENat.one_le_iff_ne_zero.mpr (by simp [hF.order_eq_zero_iff,F])
  obtain ⟨g,hg,he⟩ := (hF.natCast_le_order_iff (n:=1)).mp h1
  have he' : F =ᶠ[𝓝 u] (fun v => (v-u)*g v) := by simpa using he
  refine ⟨g,hg,?_,he'⟩
  have dleft : deriv F u = deriv c u := (hc.differentiableAt.hasDerivAt.sub_const (c u)).deriv
  have dright : deriv (fun v => (v-u)*g v) u = g u := by
    simpa using (((hasDerivAt_id u).sub_const u).mul hg.differentiableAt.hasDerivAt).deriv
  rwa [← dright, ← he'.deriv_eq, dleft]

/-- The analytic zero order of the actual logarithmic slope is exactly the
root multiplicity of the cyclotomic derivative in the corresponding chart. -/
theorem slope_order_eq_rootMultiplicity {n : ℕ} (hn : 0 < n) (s : Bool) (u : ℝ) :
    (analyticAt_slope hn s u).order =
      ((cyclotomic n ℝ).derivative.rootMultiplicity (coord s u) : ℕ∞) := by
  let D := (cyclotomic n ℝ).derivative
  let y := coord s u
  let m := D.rootMultiplicity y
  have hD : D ≠ 0 := cyclo_derivative_ne_zero hn
  obtain ⟨R,hR,hdiv⟩ := D.exists_eq_pow_rootMultiplicity_mul_and_not_dvd hD y
  have hRe : R.eval y ≠ 0 := fun hz => hdiv (dvd_iff_isRoot.mpr hz)
  have hc : deriv (coord s) u ≠ 0 := by
    rw [(coord_hasDerivAt s u).deriv]
    exact mul_ne_zero (neg_ne_zero.mpr (coord_ne_zero _ _)) (Real.exp_pos _).ne'
  obtain ⟨g,hg,hgu,hf⟩ := regular_chart_factor (analyticAt_coord s u) hc
  apply (analyticAt_slope hn s u).order_eq_nat_iff.mpr
  refine ⟨fun v => g v ^ m * R.eval (coord s v) * slopeWeight n s v,
     ((hg.pow m).mul (analytic_poly_coord R s u)).mul (analyticAt_slopeWeight hn s u),
     mul_ne_zero (mul_ne_zero (pow_ne_zero _ hgu) hRe) (slopeWeight_ne_zero hn s u), ?_⟩
  filter_upwards [hf] with v hv
  rw [slope_eq_weight_mul hn]
  change slopeWeight n s v * D.eval (coord s v) = (v-u)^m * (g v ^ m * R.eval (coord s v) * slopeWeight n s v)
  have hfac := congrArg (Polynomial.eval (coord s v)) hR
  change D.eval (coord s v) = eval (coord s v) ((X-C y)^m*R) at hfac
  rw [eval_mul, eval_pow, eval_sub, eval_X, eval_C, show y=coord s u from rfl, hv,mul_pow] at hfac
  rw [hfac]
  ring

end Cyclo
