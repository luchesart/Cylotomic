import Mathlib.RingTheory.Polynomial.Cyclotomic.Expand
import Mathlib.Analysis.Calculus.Deriv.Polynomial
import Mathlib.Analysis.SpecialFunctions.Log.Deriv
import Mathlib.Tactic

/-! The two real logarithmic charts and the prime-extension identity for the actual
mathlib cyclotomic polynomials. `s = true` selects the positive chart. -/
noncomputable section
open Polynomial
namespace Cyclo

def coord (s : Bool) (u : ℝ) : ℝ :=
  if s then Real.exp (-Real.exp u) else -Real.exp (-Real.exp u)

def profile (n : ℕ) (s : Bool) (u : ℝ) : ℝ :=
  Real.log ((cyclotomic n ℝ).eval (coord s u))

def slope (n : ℕ) (s : Bool) (u : ℝ) : ℝ := deriv (profile n s) u

theorem abs_coord (s : Bool) (u : ℝ) : |coord s u| = Real.exp (-Real.exp u) := by
  cases s <;> simp [coord, abs_of_pos (Real.exp_pos _)]

theorem abs_coord_lt_one (s : Bool) (u : ℝ) : |coord s u| < 1 := by
  rw [abs_coord, Real.exp_lt_one_iff]
  exact neg_lt_zero.mpr (Real.exp_pos _)

theorem coord_ne_zero (s : Bool) (u : ℝ) : coord s u ≠ 0 := by
  cases s <;> simp [coord]

theorem coord_neg_range (u : ℝ) : coord false u ∈ Set.Ioo (-1 : ℝ) 0 := by
  refine ⟨?_, neg_lt_zero.mpr (Real.exp_pos _)⟩
  exact neg_lt_neg (Real.exp_lt_one_iff.mpr (neg_lt_zero.mpr (Real.exp_pos _)))

theorem coord_pos_range (u : ℝ) : coord true u ∈ Set.Ioo (0 : ℝ) 1 := by
  exact ⟨Real.exp_pos _, Real.exp_lt_one_iff.mpr (neg_lt_zero.mpr (Real.exp_pos _))⟩

theorem coord_pos_strictAnti : StrictAnti (coord true) := by
  intro u v huv
  exact Real.exp_lt_exp.mpr (neg_lt_neg (Real.exp_lt_exp.mpr huv))

theorem coord_neg_strictMono : StrictMono (coord false) := by
  intro u v huv
  exact neg_lt_neg (coord_pos_strictAnti huv)

theorem coord_hasDerivAt (s : Bool) (u : ℝ) :
    HasDerivAt (coord s) (-(coord s u) * Real.exp u) u := by
  have h := ((Real.hasDerivAt_exp u).neg).exp
  cases s
  · convert h.neg using 1; simp [coord]
  · convert h using 1; simp [coord]

theorem cyclo_eval_ne_zero {n : ℕ} (hn : 0 < n) {x : ℝ} (hx : |x| < 1) :
    (cyclotomic n ℝ).eval x ≠ 0 := by
  intro h
  have hroot : (cyclotomic n ℝ).IsRoot x := h
  have hr := hroot.dvd (cyclotomic.dvd_X_pow_sub_one n ℝ)
  have hxpow : x^n = 1 := sub_eq_zero.mp (by simpa [Polynomial.IsRoot.def] using hr)
  have hlt := pow_lt_one₀ (abs_nonneg x) hx hn.ne'
  rw [← abs_pow, hxpow, abs_one] at hlt
  exact lt_irrefl _ hlt

theorem profile_hasDerivAt {n : ℕ} (hn : 0 < n) (s : Bool) (u : ℝ) :
    HasDerivAt (profile n s)
      (((cyclotomic n ℝ).derivative.eval (coord s u)) * (-(coord s u) * Real.exp u) /
       ((cyclotomic n ℝ).eval (coord s u))) u := by
  exact (((cyclotomic n ℝ).hasDerivAt (coord s u)).comp u (coord_hasDerivAt s u)).log
    (cyclo_eval_ne_zero hn (abs_coord_lt_one s u))

theorem slope_eq_polynomial {n : ℕ} (hn : 0 < n) (s : Bool) (u : ℝ) :
    slope n s u = ((cyclotomic n ℝ).derivative.eval (coord s u)) *
      (-(coord s u) * Real.exp u) / ((cyclotomic n ℝ).eval (coord s u)) :=
  (profile_hasDerivAt hn s u).deriv

theorem slope_eq_zero_iff {n : ℕ} (hn : 0 < n) (s : Bool) (u : ℝ) :
    slope n s u = 0 ↔ (cyclotomic n ℝ).derivative.eval (coord s u) = 0 := by
  simp [slope_eq_polynomial hn, coord_ne_zero, cyclo_eval_ne_zero hn (abs_coord_lt_one s u)]

theorem coord_shift {p : ℕ} (hp : 0 < p) (hodd : Odd p) (s : Bool) (u : ℝ) :
    coord s (u + Real.log p) = (coord s u)^p := by
  have hp' : (0:ℝ)<p := by exact_mod_cast hp
  have h : Real.exp (-Real.exp (u + Real.log p)) = Real.exp (-Real.exp u)^p := by
    rw [Real.exp_add, Real.exp_log hp', ← Real.exp_nat_mul]
    congr 1
    ring
  cases s <;> simp [coord, h, hodd.neg_pow]

theorem profile_mul_prime {p n : ℕ} (hn : 0 < n) (hp : p.Prime) (ho : Odd p)
    (hdiv : ¬ p ∣ n) (s : Bool) (u : ℝ) :
    profile (n*p) s u = profile n s (u + Real.log p) - profile n s u := by
  have h := congrArg (Polynomial.eval (coord s u))
    (cyclotomic_expand_eq_cyclotomic_mul hp hdiv ℝ)
  rw [Polynomial.expand_eval, Polynomial.eval_mul, ← coord_shift hp.pos ho] at h
  unfold profile
  rw [h, Real.log_mul (cyclo_eval_ne_zero (Nat.mul_pos hn hp.pos) (abs_coord_lt_one s u))
    (cyclo_eval_ne_zero hn (abs_coord_lt_one s u))]
  ring

theorem slope_mul_prime {p n : ℕ} (hn : 0 < n) (hp : p.Prime) (ho : Odd p)
    (hdiv : ¬ p ∣ n) (s : Bool) (u : ℝ) :
    slope (n*p) s u = slope n s (u + Real.log p) - slope n s u := by
  have hf (v : ℝ) : HasDerivAt (profile n s) (slope n s v) v :=
    (profile_hasDerivAt hn s v).differentiableAt.hasDerivAt
  have ha := (hf (u + Real.log p)).comp u ((hasDerivAt_id u).add_const (Real.log p))
  have hb := ha.sub (hf u)
  change deriv (profile (n*p) s) u = _
  rw [show profile (n*p) s = (fun v => profile n s (v + Real.log p) - profile n s v)
      from funext (profile_mul_prime hn hp ho hdiv s)]
  simpa [Function.comp_def] using hb.deriv

theorem prime_not_dvd_prod {p : ℕ} (hp : p.Prime) (ps : List ℕ)
    (hall : ∀ q ∈ ps, Nat.Prime q) (hnot : p ∉ ps) : ¬p ∣ ps.prod := by
  induction ps with
  | nil => simpa using hp.not_dvd_one
  | cons q qs ih =>
    rw [List.prod_cons, hp.dvd_mul]
    push_neg
    refine ⟨?_,ih (fun r hr => hall r (by simp [hr])) (fun h => hnot (by simp [h]))⟩
    intro hd
    rcases (Nat.dvd_prime (hall q (by simp))).mp hd with h|h
    · exact hp.ne_one h
    · exact hnot (by simp [h])

theorem prime_list_prod_pos (ps : List ℕ) (hall : ∀ q ∈ ps, Nat.Prime q) : 0 < ps.prod := by
  exact Nat.pos_of_ne_zero (List.prod_ne_zero fun h => (hall 0 h).ne_zero rfl)


theorem slope_one_pos (u : ℝ) :
    slope 1 true u = Real.exp u / (Real.exp (Real.exp u) - 1) := by
  rw [slope_eq_polynomial (by decide : 0 < 1)]
  simp only [Polynomial.cyclotomic_one, Polynomial.derivative_sub, Polynomial.derivative_X,
    Polynomial.derivative_one, sub_zero, Polynomial.eval_one, Polynomial.eval_sub,
    Polynomial.eval_X, coord, if_true]
  rw [Real.exp_neg]
  have he := Real.exp_pos (Real.exp u)
  have hlt : 1 < Real.exp (Real.exp u) := Real.one_lt_exp_iff.mpr (Real.exp_pos u)
  field_simp [he.ne', sub_ne_zero.mpr hlt.ne', sub_ne_zero.mpr hlt.ne]; ring

theorem slope_one_neg (u : ℝ) :
    slope 1 false u = -Real.exp u / (Real.exp (Real.exp u) + 1) := by
  rw [slope_eq_polynomial (by decide : 0 < 1)]
  simp only [Polynomial.cyclotomic_one, Polynomial.derivative_sub, Polynomial.derivative_X,
    Polynomial.derivative_one, sub_zero, Polynomial.eval_one, Polynomial.eval_sub,
    Polynomial.eval_X, coord, Bool.false_eq_true, if_false]
  rw [Real.exp_neg]
  have he := Real.exp_pos (Real.exp u)
  have hp : 0 < Real.exp (Real.exp u) + 1 := by positivity
  have hn : (-1 : ℝ) - Real.exp (Real.exp u) ≠ 0 := by linarith
  field_simp [he.ne', hp.ne', hn]; ring

/-- The exact prime-list difference identity. The list may be in any order. -/
theorem slope_prime_list (ps : List ℕ) (hn : ps.Nodup)
    (hpr : ∀ p ∈ ps, Nat.Prime p) (hod : ∀ p ∈ ps, Odd p) (s : Bool) :
    slope ps.prod s = (ps.map (fun (p : ℕ) => Real.log (p : ℝ))).foldr
      (fun a (f : ℝ → ℝ) (u : ℝ) => f (u+a) - f u) (slope 1 s) := by
  induction ps with
  | nil => rfl
  | cons p ps ih =>
    rcases List.nodup_cons.mp hn with ⟨hnot, hnd⟩
    have hpr' : ∀ q ∈ ps, Nat.Prime q := fun q h => hpr q (by simp [h])
    have hod' : ∀ q ∈ ps, Odd q := fun q h => hod q (by simp [h])
    have hp := hpr p (by simp)
    have h := slope_mul_prime (prime_list_prod_pos ps hpr') hp (hod p (by simp))
      (prime_not_dvd_prod hp ps hpr' hnot) s
    funext u
    simp only [List.prod_cons, List.map_cons, List.foldr_cons]
    rw [Nat.mul_comm p, h u, ih hnd hpr' hod']


theorem continuous_coord (s : Bool) : Continuous (coord s) :=
  continuous_iff_continuousAt.mpr (fun u => (coord_hasDerivAt s u).continuousAt)

theorem range_coord_pos : Set.range (coord true) = Set.Ioo (0:ℝ) 1 := by
  ext x
  constructor
  · rintro ⟨u,rfl⟩
    exact coord_pos_range u
  · intro hx
    have hlog : 0 < -(Real.log x) := neg_pos.mpr (Real.log_neg hx.1 hx.2)
    refine ⟨Real.log (- Real.log x), ?_⟩
    change Real.exp (-Real.exp (Real.log (-Real.log x))) = x
    rw [Real.exp_log hlog,neg_neg,Real.exp_log hx.1]

theorem range_coord_neg : Set.range (coord false) = Set.Ioo (-1:ℝ) 0 := by
  ext x
  constructor
  · rintro ⟨u,rfl⟩
    exact coord_neg_range u
  · intro hx
    have hpos : -x ∈ Set.range (coord true) := by
      rw [range_coord_pos]
      exact ⟨neg_pos.mpr hx.2, by linarith [hx.1]⟩
    obtain ⟨u,hu⟩ := hpos
    exact ⟨u, show -(coord true u) = x by rw [hu,neg_neg]⟩

def slopeWeight (n : ℕ) (s : Bool) (u : ℝ) :=
  (-(coord s u) * Real.exp u) / ((cyclotomic n ℝ).eval (coord s u))

theorem slopeWeight_ne_zero {n : ℕ} (hn : 0 < n) (s : Bool) (u : ℝ) :
    slopeWeight n s u ≠ 0 := by
  exact div_ne_zero (mul_ne_zero (neg_ne_zero.mpr (coord_ne_zero _ _)) (Real.exp_pos _).ne')
    (cyclo_eval_ne_zero hn (abs_coord_lt_one _ _))

theorem continuous_slopeWeight {n : ℕ} (hn : 0 < n) (s : Bool) :
    Continuous (slopeWeight n s) := by
  exact ((continuous_coord s).neg.mul Real.continuous_exp).div
    ((cyclotomic n ℝ).continuous.comp (continuous_coord s))
    (fun u => cyclo_eval_ne_zero hn (abs_coord_lt_one s u))

theorem slope_eq_weight_mul {n : ℕ} (hn : 0 < n) (s : Bool) (u : ℝ) :
    slope n s u = slopeWeight n s u * (cyclotomic n ℝ).derivative.eval (coord s u) := by
  rw [slope_eq_polynomial hn]
  unfold slopeWeight
  ring

theorem cyclo_derivative_ne_zero {n : ℕ} (hn : 0 < n) :
    (cyclotomic n ℝ).derivative ≠ 0 := by
  intro h
  have hz := natDegree_eq_zero_of_derivative_eq_zero h
  rw [natDegree_cyclotomic] at hz
  exact (Nat.totient_pos.mpr hn).ne' hz

end Cyclo
