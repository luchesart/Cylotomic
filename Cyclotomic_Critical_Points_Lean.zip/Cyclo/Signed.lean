import Cyclo.Identity
import Cyclo.Moments
import Cyclo.Kernels
import Cyclo.PolynomialSigns

/-! The main theorem for mathlib's actual cyclotomic polynomials. -/
noncomputable section
open Polynomial Set MeasureTheory
namespace Cyclo

private theorem foldr_eq_iterDelta (shifts : List ℝ) (f : ℝ → ℝ) :
    shifts.foldr (fun a (g : ℝ → ℝ) (u : ℝ) => g (u+a) - g u) f = iterDelta shifts f := by
  induction shifts with
  | nil => rfl
  | cons a rest ih => simp only [List.foldr_cons, iterDelta, ih]; rfl

/-- The Möbius log-derivative identity on the negative arc. -/
theorem slope_neg_eq_iterDelta (ps : List ℕ) (hd : ps.Nodup)
    (hp : ∀ q ∈ ps, Nat.Prime q) (ho : ∀ q ∈ ps, Odd q) :
    slope ps.prod false = iterDelta (ps.map (fun (q : ℕ) => Real.log (q : ℝ))) kernelNeg := by
  rw [slope_prime_list ps hd hp ho, foldr_eq_iterDelta]
  exact congrArg _ (funext slope_one_neg)

/-- The same identity on the positive arc. -/
theorem slope_pos_eq_iterDelta (ps : List ℕ) (hd : ps.Nodup)
    (hp : ∀ q ∈ ps, Nat.Prime q) (ho : ∀ q ∈ ps, Odd q) :
    slope ps.prod true = iterDelta (ps.map (fun (q : ℕ) => Real.log (q : ℝ))) kernelPos := by
  rw [slope_prime_list ps hd hp ho, foldr_eq_iterDelta]
  exact congrArg _ (funext slope_one_pos)

private theorem delta_commutes (a b : ℝ) (f : ℝ → ℝ) :
    delta a (delta b f) = delta b (delta a f) := by
  funext x
  unfold delta
  rw [show x+a+b = x+b+a by ring]
  ring

private theorem delta_iterDelta (a : ℝ) (shifts : List ℝ) (f : ℝ → ℝ) :
    delta a (iterDelta shifts f) = iterDelta shifts (delta a f) := by
  induction shifts with
  | nil => rfl
  | cons b rest ih => rw [iterDelta, iterDelta, delta_commutes, ih]

private theorem chart_bound {n : ℕ} (hn : 0 < n) (s : Bool) (shifts : List ℝ) (f : ℝ → ℝ)
    (hf : AllMoments f) (hsl : slope n s = iterDelta shifts f) :
    shifts.length ≤ (oddRootsIn (cyclotomic n ℝ).derivative (range (coord s))).card := by
  have hm : StrictMono (coord s) ∨ StrictAnti (coord s) := by
    cases s
    · exact Or.inl coord_neg_strictMono
    · exact Or.inr coord_pos_strictAnti
  apply oddRootsIn_card_of_orthogonal _ (cyclo_derivative_ne_zero hn) _ (slopeWeight n s)
    (continuous_coord s) hm (continuous_slopeWeight hn s) (slopeWeight_ne_zero hn s)
  intro P hP
  simp_rw [← slope_eq_weight_mul hn, hsl]
  exact ⟨allMoments_iterDelta hf shifts P,
    integral_iterDelta_eq_zero hf shifts P (lt_of_le_of_lt degree_le_natDegree
      (WithBot.coe_lt_coe.mpr hP))⟩

/-- For every product of distinct odd primes, its derivative has at least k negative
and k-1 positive distinct roots of odd multiplicity. -/
theorem signed_lower_bounds (ps : List ℕ) (hd : ps.Nodup)
    (hp : ∀ q ∈ ps, Nat.Prime q) (ho : ∀ q ∈ ps, Odd q) :
    ps.length ≤ (oddRootsIn (cyclotomic ps.prod ℝ).derivative (Ioo (-1 : ℝ) 0)).card ∧
    ps.length - 1 ≤ (oddRootsIn (cyclotomic ps.prod ℝ).derivative (Ioo (0 : ℝ) 1)).card := by
  have hn := prime_list_prod_pos ps hp
  constructor
  · have H := chart_bound hn false _ _ (allMoments_of_powers kernelNeg_integrable_moment)
      (slope_neg_eq_iterDelta ps hd hp ho)
    simpa [range_coord_neg] using H
  · cases ps with
    | nil => simp
    | cons p rest =>
      let a := Real.log (p : ℝ)
      let shifts := rest.map (fun (q : ℕ) => Real.log (q : ℝ))
      have hsl : slope (p :: rest).prod true = iterDelta shifts (delta a kernelPos) := by
        rw [slope_pos_eq_iterDelta (p :: rest) hd hp ho]
        exact delta_iterDelta a shifts kernelPos
      have H := chart_bound hn true shifts _ (allMoments_of_powers (kernelPos_diff_integrable_moment a)) hsl
      simpa [shifts, range_coord_pos] using H

/-- Sum of the signed counts in disjoint intervals. This counts distinct roots of
odd multiplicity in the two arcs. -/
theorem total_lower_bound (ps : List ℕ) (hne : ps ≠ []) (hd : ps.Nodup)
    (hp : ∀ q ∈ ps, Nat.Prime q) (ho : ∀ q ∈ ps, Odd q) :
    2*ps.length - 1 ≤
      (oddRootsIn (cyclotomic ps.prod ℝ).derivative (Ioo (-1 : ℝ) 0)).card +
      (oddRootsIn (cyclotomic ps.prod ℝ).derivative (Ioo (0 : ℝ) 1)).card := by
  obtain ⟨h1,h2⟩ := signed_lower_bounds ps hd hp ho
  have hlen : 0 < ps.length := List.length_pos_iff.mpr hne
  omega


/-- Hong--Sommese's lower counting inequality; `roots.card` counts real roots with
multiplicity because the coefficient field here is ℝ. -/
theorem card_real_roots_lower_bound (ps : List ℕ) (hne : ps ≠ []) (hd : ps.Nodup)
    (hp : ∀ q ∈ ps, Nat.Prime q) (ho : ∀ q ∈ ps, Odd q) :
    2*ps.length-1 ≤ (cyclotomic ps.prod ℝ).derivative.roots.card := by
  classical
  let D := (cyclotomic ps.prod ℝ).derivative
  let L := oddRootsIn D (Ioo (-1:ℝ) 0)
  let R := oddRootsIn D (Ioo (0:ℝ) 1)
  have hlr : Disjoint L R := by
    apply Finset.disjoint_left.mpr
    intro x hx hx'
    simp only [L,R,oddRootsIn,Finset.mem_filter] at hx hx'
    have hn : x < 0 := hx.2.1.2
    have hp : 0 < x := hx'.2.1.1
    exact (not_lt_of_ge hn.le) hp
  have hsub : L ∪ R ⊆ D.roots.toFinset := by
    intro x hx
    simp only [L,R,oddRootsIn,Finset.mem_union,Finset.mem_filter] at hx
    exact hx.elim And.left And.left
  calc
    2*ps.length - 1 ≤ L.card + R.card := total_lower_bound ps hne hd hp ho
    _ = (L ∪ R).card := (Finset.card_union_of_disjoint hlr).symm
    _ ≤ D.roots.toFinset.card := Finset.card_le_card hsub
    _ ≤ D.roots.card := Multiset.toFinset_card_le _

end Cyclo
