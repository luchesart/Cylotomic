import Cyclo.CertificateData
namespace Cyclo.Cert

/-- Sum of absolute coefficient values. -/
def mass : List ℤ → ℤ
  | [] => 0
  | a::l => |a| + mass l

theorem mass_nonneg (l : List ℤ) : 0 ≤ mass l := by
  induction l with
  | nil => exact le_rfl
  | cons a l ih => exact add_nonneg (abs_nonneg _) ih

theorem abs_le_mass_of_mem {a : ℤ} {l : List ℤ} (ha : a ∈ l) : |a| ≤ mass l := by
  induction l with
  | nil => simp at ha
  | cons b l ih =>
    rcases List.mem_cons.mp ha with rfl|h
    · exact le_add_of_nonneg_right (mass_nonneg _)
    · exact (ih h).trans (le_add_of_nonneg_left (abs_nonneg _))

theorem mass_add_le (l r : List ℤ) : mass (add l r) ≤ mass l + mass r := by
  induction l generalizing r with
  | nil => simp [add,mass]
  | cons a l ih =>
    cases r with
    | nil => simp [add,mass]
    | cons b r =>
      change |a+b| + mass (add l r) ≤ (|a|+mass l)+(|b|+mass r)
      linarith only [ih r, abs_add_le a b]

theorem mass_scale (a : ℤ) (l : List ℤ) : mass (scale a l) = |a| * mass l := by
  induction l with
  | nil => simp [mass,scale]
  | cons b l ih =>
    change |a*b| + mass (scale a l) = |a| * (|b|+mass l)
    rw [abs_mul,ih,mul_add]

theorem homog_mass (s : ℤ) (hs : |s| ≤ 1) (l : List ℤ) :
    mass (homog s l).1 ≤ (2:ℤ)^l.length * mass l ∧
    mass (homog s l).2 ≤ (2:ℤ)^l.length := by
  match l with
  | [] => norm_num [homog,mass]
  | [a] => simp [homog,mass]; linarith [abs_nonneg a]
  | a::b::l =>
    let prev := homog s (b::l)
    let den := add prev.2 (0::prev.2)
    let T := (2:ℤ)^(b::l).length
    have hT : 0 ≤ T := by dsimp [T]; positivity
    obtain ⟨h1,h2⟩ := homog_mass s hs (b::l)
    change mass prev.1 ≤ T * mass (b::l) at h1
    change mass prev.2 ≤ T at h2
    have hden : mass den ≤ 2*T := by
      have hh := mass_add_le prev.2 (0::prev.2)
      change mass den ≤ mass prev.2 + (|0| + mass prev.2) at hh
      simp only [abs_zero,zero_add] at hh
      omega
    change mass (add (scale a den) (0::scale s prev.1)) ≤ (2:ℤ)^((b::l).length+1) * (|a|+mass (b::l)) ∧
      mass den ≤ (2:ℤ)^((b::l).length+1)
    rw [pow_succ]
    constructor
    · have hh := mass_add_le (scale a den) (0::scale s prev.1)
      simp only [mass,abs_zero,zero_add,mass_scale] at hh
      have ha := mul_le_mul_of_nonneg_left hden (abs_nonneg a)
      have hsm := mul_le_mul_of_nonneg_right hs (mass_nonneg prev.1)
      have hm := mul_nonneg hT (mass_nonneg (b::l))
      nlinarith only [hh,ha,hsm,h1,hm]
    · linarith
end Cyclo.Cert
