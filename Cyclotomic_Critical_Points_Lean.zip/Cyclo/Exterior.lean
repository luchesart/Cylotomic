import Mathlib.RingTheory.Polynomial.Cyclotomic.Roots
import Mathlib.RingTheory.RootsOfUnity.Complex
import Mathlib.Analysis.Calculus.Deriv.Polynomial

/-! Real critical points are strictly between the extreme real parts of the
primitive roots. This gives a direct half-plane proof of the exterior
exclusion used in the finite certificates. -/
namespace Cyclo
open Set Finset Polynomial

private theorem primitive_im_ne {n : ℕ} (hn : 2 < n) {z : ℂ} (hz : IsPrimitiveRoot z n) :
    z.im ≠ 0 := by
  intro h
  have hsq := Complex.sq_norm z
  rw [hz.norm'_eq_one (by omega), Complex.normSq_apply, h] at hsq
  have hp : z ^ 2 = 1 := by
    apply Complex.ext
    · simp only [pow_two, Complex.mul_re, h, zero_mul, sub_zero, Complex.one_re]
      nlinarith
    · simp [pow_two, Complex.mul_im, h]
  have hle := Nat.le_of_dvd (by decide : 0 < 2) ((hz.pow_eq_one_iff_dvd 2).mp hp)
  omega

/-- An elementary log-derivative identity at any point avoiding the linear factors. -/
private theorem factor_log_sum (s : Finset ℂ) (w : ℂ) (h : ∀ z ∈ s, w ≠ z) :
    (∏ z ∈ s, (X - C z : ℂ[X])).derivative.eval w =
      (∏ z ∈ s, (w-z)) * ∑ z ∈ s, (w-z)⁻¹ := by
  classical
  induction s using Finset.induction_on with
  | empty => simp
  | @insert a s ha ih =>
    have hw : w-a ≠ 0 := sub_ne_zero.mpr (h a (Finset.mem_insert_self _ _))
    have hrest := ih (fun z hz => h z (Finset.mem_insert_of_mem hz))
    simp only [Finset.prod_insert ha, Finset.sum_insert ha, derivative_mul,
      derivative_X_sub_C, one_mul, eval_add, eval_mul, eval_sub, eval_X, eval_C]
    rw [hrest, eval_prod]
    simp only [eval_sub, eval_X, eval_C]
    field_simp [hw]
    ring

/-- For every order greater than two, every real zero of the derivative
of mathlib's cyclotomic polynomial lies strictly inside the signed unit interval. -/
theorem cyclotomic_critical_mem_Ioo {n : ℕ} (hn : 2 < n) {x : ℝ}
    (hx : (cyclotomic n ℝ).derivative.eval x = 0) : x ∈ Ioo (-1 : ℝ) 1 := by
  classical
  have hn0 : n ≠ 0 := by omega
  have hnpos : 0 < n := by omega
  let s := primitiveRoots n ℂ
  have hpr {z : ℂ} (hz : z ∈ s) : IsPrimitiveRoot z n := (mem_primitiveRoots hnpos).mp hz
  have hne : ∀ z ∈ s, (x : ℂ) ≠ z := by
    intro z hz he
    have him := primitive_im_ne hn (hpr hz)
    exact him (by rw [← he]; rfl)
  have hre {z : ℂ} (hz : z ∈ s) : -1 < z.re ∧ z.re < 1 := by
    have hh := Complex.abs_re_lt_norm.mpr (primitive_im_ne hn (hpr hz))
    rw [(hpr hz).norm'_eq_one hn0] at hh
    exact abs_lt.mp hh
  have hcomplex : (cyclotomic n ℂ).derivative.eval (x : ℂ) = 0 := by
    rw [←map_cyclotomic n Complex.ofRealHom, derivative_map, eval_map]
    change eval₂ Complex.ofRealHom (Complex.ofRealHom x) _ = 0
    rw [eval₂_at_apply, hx, map_zero]
  have hp := Complex.isPrimitiveRoot_exp n hn0
  have hnonempty : s.Nonempty := ⟨_, (mem_primitiveRoots hnpos).mpr hp⟩
  rw [cyclotomic_eq_prod_X_sub_primitiveRoots hp] at hcomplex
  have hzero := (factor_log_sum s (x : ℂ) hne).symm.trans hcomplex
  have hprod : (∏ z ∈ s, ((x : ℂ)-z)) ≠ 0 :=
    Finset.prod_ne_zero_iff.mpr (fun z hz => sub_ne_zero.mpr (hne z hz))
  have hsum := (mul_eq_zero.mp hzero).resolve_left hprod
  have hreal := congrArg Complex.re hsum
  rw [Complex.re_sum, Complex.zero_re] at hreal
  have denom {z : ℂ} (hz : z ∈ s) : 0 < Complex.normSq ((x : ℂ)-z) :=
    Complex.normSq_pos.mpr (sub_ne_zero.mpr (hne z hz))
  constructor
  · by_contra! h
    have hneg : ∑ z ∈ s, ((x : ℂ)-z)⁻¹.re < 0 := by
      apply Finset.sum_neg _ hnonempty
      intro z hz
      rw [Complex.inv_re, Complex.sub_re, Complex.ofReal_re]
      exact div_neg_of_neg_of_pos (sub_neg.mpr (lt_of_le_of_lt h (hre hz).1)) (denom hz)
    linarith
  · by_contra! h
    have hpos : 0 < ∑ z ∈ s, ((x : ℂ)-z)⁻¹.re := by
      apply Finset.sum_pos _ hnonempty
      intro z hz
      rw [Complex.inv_re, Complex.sub_re, Complex.ofReal_re]
      exact div_pos (sub_pos.mpr (lt_of_lt_of_le (hre hz).2 h)) (denom hz)
    linarith

end Cyclo
