import Mathlib

open MeasureTheory Polynomial Set
open scoped Polynomial
noncomputable section
namespace Cyclo

/-- Forward difference in the logarithmic coordinate. -/
def delta (a : ℝ) (f : ℝ → ℝ) (x : ℝ) := f (x + a) - f x

/-- The empty list is the identity filter. -/
def iterDelta : List ℝ → (ℝ → ℝ) → ℝ → ℝ
  | [], f => f
  | a :: rest, f => delta a (iterDelta rest f)

/-- Absolute integrability against every polynomial weight. -/
def AllMoments (f : ℝ → ℝ) : Prop :=
  ∀ p : ℝ[X], Integrable (fun x => p.eval x * f x)

theorem allMoments_of_powers {f : ℝ → ℝ} (h : ∀ m : ℕ, Integrable (fun u : ℝ => u ^ m * f u)) :
    AllMoments f := by
  intro p
  induction p using Polynomial.induction_on' with
  | add p q hp hq => simpa [add_mul] using hp.add hq
  | monomial n c => simpa [mul_assoc] using (h n).const_mul c

private theorem shifted_weight {f : ℝ → ℝ} (hf : AllMoments f) (p : ℝ[X]) (a : ℝ) :
    Integrable (fun x => p.eval x * f (x + a)) := by
  simpa [Polynomial.taylor_eval] using (hf (taylor (-a) p)).comp_add_right a

theorem allMoments_delta {f : ℝ → ℝ} (hf : AllMoments f) (a : ℝ) :
    AllMoments (delta a f) := by
  intro p
  simpa [delta, mul_sub] using (shifted_weight hf p a).sub (hf p)

theorem allMoments_iterDelta {f : ℝ → ℝ} (hf : AllMoments f) (shifts : List ℝ) :
    AllMoments (iterDelta shifts f) := by
  induction shifts with
  | nil => exact hf
  | cons a rest ih => exact allMoments_delta ih a

/-- Translation invariance moves a forward difference onto a backwards-shifted test. -/
theorem integral_delta {f : ℝ → ℝ} (hf : AllMoments f) (p : ℝ[X]) (a : ℝ) :
    (∫ x, p.eval x * delta a f x) =
      ∫ x, (taylor (-a) p - p).eval x * f x := by
  simp only [delta, mul_sub, eval_sub, sub_mul]
  rw [integral_sub (shifted_weight hf p a) (hf p), integral_sub (hf _) (hf p)]
  congr 1
  simpa [Polynomial.taylor_eval] using
    (integral_add_right_eq_self (μ := volume) (fun x : ℝ => (taylor (-a) p).eval x * f x) a)

private theorem shifted_degree_lt {p : ℝ[X]} (hp : p ≠ 0) (a : ℝ) :
    (taylor a p - p).degree < p.degree := by
  have ht : taylor a p ≠ 0 := by
    intro h
    exact hp (taylor_injective a (h.trans (map_zero _).symm))
  have hd : (taylor a p).degree = p.degree := by
    simp [degree_eq_natDegree ht, degree_eq_natDegree hp]
  rw [← hd]
  apply Polynomial.degree_sub_lt hd ht
  simp [taylor_apply, leadingCoeff_comp]

/-- A filter with k differences annihilates every test polynomial of degree below k. -/
theorem integral_iterDelta_eq_zero {f : ℝ → ℝ} (hf : AllMoments f)
    (shifts : List ℝ) (p : ℝ[X]) (hp : p.degree < (shifts.length : ℕ)) :
    (∫ x, p.eval x * iterDelta shifts f x) = 0 := by
  induction shifts generalizing p with
  | nil =>
    have hz : p = 0 := by
      by_contra h
      simp [degree_eq_natDegree h] at hp
    simp [hz]
  | cons a rest ih =>
    by_cases hz : p = 0
    · simp [hz]
    rw [iterDelta, integral_delta (allMoments_iterDelta hf rest) p a]
    apply ih
    have h1 := shifted_degree_lt hz (-a)
    rw [degree_eq_natDegree hz] at h1 hp
    have h2 : p.natDegree < rest.length + 1 := WithBot.coe_lt_coe.mp hp
    exact h1.trans_le (WithBot.coe_le_coe.mpr (Nat.le_of_lt_succ h2))


theorem iterDelta_append (as bs : List ℝ) (f : ℝ → ℝ) :
    iterDelta (as ++ bs) f = iterDelta as (iterDelta bs f) := by
  induction as with
  | nil => rfl
  | cons _ _ ih => simp only [List.cons_append, iterDelta, ih]

@[simp] theorem iterDelta_singleton (a : ℝ) (f : ℝ → ℝ) : iterDelta [a] f = delta a f := rfl

end Cyclo
