import Cyclo.Moments
open MeasureTheory Polynomial Set Filter Topology
open scoped Polynomial
noncomputable section
namespace Cyclo
/-- Strictly opposite signs throughout two intervals meeting at the root. -/
def Crosses (f : ℝ → ℝ) (r : ℝ) : Prop :=
  f r = 0 ∧ ∃ a < r, ∃ b > r, ∀ x ∈ Ioo a r, ∀ y ∈ Ioo r b, f x * f y < 0

private theorem same_sign_on {f : ℝ → ℝ} (hc : Continuous f) {s : Set ℝ}
    (hs : IsPreconnected s) (hn : ∀ x ∈ s, f x ≠ 0) {x y : ℝ} (hx : x ∈ s) (hy : y ∈ s) :
    0 < f x * f y := by
  rcases lt_or_gt_of_ne (hn x hx) with hx' | hx' <;>
    rcases lt_or_gt_of_ne (hn y hy) with hy' | hy'
  · exact mul_pos_of_neg_of_neg hx' hy'
  · obtain ⟨z, hz, hz'⟩ := hs.intermediate_value hx hy hc.continuousOn (show (0 : ℝ) ∈ Icc (f x) (f y) from ⟨hx'.le,hy'.le⟩)
    exact False.elim (hn z hz hz')
  · obtain ⟨z, hz, hz'⟩ := hs.intermediate_value hy hx hc.continuousOn (show (0 : ℝ) ∈ Icc (f y) (f x) from ⟨hy'.le,hx'.le⟩)
    exact False.elim (hn z hz hz')
  · exact mul_pos hx' hy'

private theorem exists_crossing {f : ℝ → ℝ} (hc : Continuous f) (hz : {x | f x = 0}.Finite)
    (hp : ∃ x, 0 < f x) (hn : ∃ x, f x < 0) : ∃ r, Crosses f r := by
  classical
  let P := {x | 0 < f x}
  let N := {x | f x < 0}
  have hP : closure P ⊆ {x | 0 ≤ f x} :=
    closure_minimal (fun x (h : 0 < f x) => (show 0 ≤ f x from le_of_lt h)) (isClosed_le continuous_const hc)
  have hN : closure N ⊆ {x | f x ≤ 0} :=
    closure_minimal (fun x (h : f x < 0) => (show f x ≤ 0 from le_of_lt h)) (isClosed_le hc continuous_const)
  have hcover : univ ⊆ closure P ∪ closure N := by
    rw [← closure_union]
    apply univ_subset_iff.mpr
    apply Dense.closure_eq
    apply (hz.countable.dense_compl ℝ).mono
    intro x h
    exact (lt_or_gt_of_ne h).symm
  have hboth : (closure P ∩ closure N).Nonempty := by
    by_contra! hempty
    have hh := (isPreconnected_iff_subset_of_disjoint_closed.mp
      (isPreconnected_univ : IsPreconnected (univ : Set ℝ))) _ _
      isClosed_closure isClosed_closure hcover (by simpa using hempty)
    rcases hh with h | h
    · obtain ⟨x,hx⟩ := hn
      exact (not_lt_of_ge (hP (h (mem_univ x)))) hx
    · obtain ⟨x,hx⟩ := hp
      exact (not_lt_of_ge (hN (h (mem_univ x)))) hx
  obtain ⟨r, hrP, hrN⟩ := hboth
  have hr : f r = 0 := le_antisymm (hN hrN) (hP hrP)
  let S := {x | f x = 0} \ {r}
  have hs : S.Finite := hz.diff
  have hrS : r ∈ Sᶜ := by simp [S]
  obtain ⟨a,b,⟨ha,hb⟩,hab⟩ := mem_nhds_iff_exists_Ioo_subset.mp
    (hs.isClosed.isOpen_compl.mem_nhds hrS)
  have hl : ∀ z ∈ Ioo a r, f z ≠ 0 := by
    intro z hz' he
    exact hab ⟨hz'.1, hz'.2.trans hb⟩ ⟨he, hz'.2.ne⟩
  have hu : ∀ z ∈ Ioo r b, f z ≠ 0 := by
    intro z hz' he
    exact hab ⟨ha.trans hz'.1, hz'.2⟩ ⟨he, hz'.1.ne'⟩
  refine ⟨r,hr,a,ha,b,hb,?_⟩
  intro x hx y hy
  apply lt_of_not_ge
  intro hxy
  have hxy' : 0 < f x * f y := lt_of_le_of_ne hxy (mul_ne_zero (hl x hx) (hu y hy)).symm
  have hnb := Ioo_mem_nhds ha hb
  have hsame (z : ℝ) (hz' : z ∈ Ioo a b) (hz0 : f z ≠ 0) : 0 < f x * f z := by
    rcases lt_trichotomy z r with h | h | h
    · exact same_sign_on hc isPreconnected_Ioo hl hx ⟨hz'.1,h⟩
    · exact False.elim (hz0 (h ▸ hr))
    · have h2 := same_sign_on hc isPreconnected_Ioo hu hy ⟨h,hz'.2⟩
      rcases mul_pos_iff.mp hxy' with hpos | hneg
      · exact mul_pos hpos.1 ((mul_pos_iff_of_pos_left hpos.2).mp h2)
      · exact mul_pos_of_neg_of_neg hneg.1 (lt_of_not_ge (fun h => (not_lt_of_ge (mul_nonpos_of_nonpos_of_nonneg hneg.2.le h)) h2))
  rcases lt_or_gt_of_ne (hl x hx) with hneg | hpos
  · obtain ⟨z,hz',hzP⟩ := (mem_closure_iff_nhds.mp hrP) _ hnb
    exact (not_lt_of_ge (mul_nonpos_of_nonpos_of_nonneg hneg.le (le_of_lt hzP)))
      (hsame z hz' (ne_of_gt hzP))
  · obtain ⟨z,hz',hzN⟩ := (mem_closure_iff_nhds.mp hrN) _ hnb
    exact (not_lt_of_ge (mul_nonpos_of_nonneg_of_nonpos hpos.le (le_of_lt hzN)))
      (hsame z hz' (ne_of_lt hzN))

private theorem integral_zero_both_signs {f : ℝ → ℝ} (hf : Continuous f)
    (hi : Integrable f) (hn : ∃ x, f x ≠ 0) (hz : ∫ x, f x = 0) :
    (∃ x, 0 < f x) ∧ ∃ x, f x < 0 := by
  obtain ⟨v,hv⟩ := hn
  constructor
  · by_contra! h
    have hpos := integral_pos_of_integrable_nonneg_nonzero hf.neg hi.neg
      (fun x => neg_nonneg.mpr (h x)) (neg_ne_zero.mpr hv)
    simp [integral_neg,hz] at hpos
  · by_contra! h
    have hpos := integral_pos_of_integrable_nonneg_nonzero hf hi h hv
    simp [hz] at hpos

private theorem crossing_removed {f : ℝ → ℝ} {r : ℝ} (h : Crosses f r) :
    ¬ Crosses (fun u => (u-r) * f u) r := by
  rintro ⟨_,c,hc,d,hd,ht⟩
  obtain ⟨_,a,ha,b,hb,hu⟩ := h
  obtain ⟨x,hx1,hx2⟩ := exists_between (max_lt ha hc)
  obtain ⟨y,hy1,hy2⟩ := exists_between (lt_min hb hd)
  obtain ⟨hxa,hxc⟩ := max_lt_iff.mp hx1
  obtain ⟨hyb,hyd⟩ := lt_min_iff.mp hy2
  have hbefore := hu _ ⟨hxa,hx2⟩ _ ⟨hy1,hyb⟩
  have hafter := ht _ ⟨hxc,hx2⟩ _ ⟨hy1,hyd⟩
  have hp := mul_pos_of_neg_of_neg (mul_neg_of_neg_of_pos (sub_neg.mpr hx2) (sub_pos.mpr hy1)) hbefore
  dsimp only at hafter
  linarith only [show (x-r)*(y-r)*(f x*f y) = ((x-r)*f x)*((y-r)*f y) by ring,hafter,hp]

private theorem crossing_other {f : ℝ → ℝ} {r z : ℝ} (hz : z ≠ r)
    (h : Crosses (fun x => (x-r) * f x) z) : Crosses f z := by
  obtain ⟨ht,a,ha,b,hb,hw⟩ := h
  refine ⟨(mul_eq_zero.mp ht).resolve_left (sub_ne_zero.mpr hz),?_⟩
  have shrink (x y : ℝ) (hx : x ∈ Ioo a z) (hy : y ∈ Ioo z b)
      (hk : 0 < (x-r)*(y-r)) : f x * f y < 0 := by
    apply lt_of_not_ge
    intro hpos
    have hs := hw x hx y hy
    dsimp only at hs
    have hp := mul_nonneg hk.le hpos
    linarith only [show (x-r)*(y-r)*(f x*f y) = ((x-r)*f x)*((y-r)*f y) by ring,hs,hp]
  rcases lt_or_gt_of_ne hz with hlt | hgt
  · refine ⟨a,ha,min b r,lt_min hb hlt,?_⟩
    intro x hx y hy
    apply shrink x y hx ⟨hy.1,hy.2.trans_le (min_le_left _ _)⟩
    exact mul_pos_of_neg_of_neg (sub_neg.mpr (hx.2.trans hlt)) (sub_neg.mpr (hy.2.trans_le (min_le_right _ _)))
  · refine ⟨max a r,max_lt ha hgt,b,hb,?_⟩
    intro x hx y hy
    apply shrink x y ⟨(le_max_left a r).trans_lt hx.1,hx.2⟩ hy
    exact mul_pos (sub_pos.mpr ((le_max_right a r).trans_lt hx.1)) (sub_pos.mpr (hgt.trans hy.1))

/-- Orthogonality to every polynomial of degree below m forces m distinct sign-changing
zeros of a continuous function with finitely many zeros and finite absolute moments. -/
theorem sign_changes_of_orthogonality (m : ℕ) {f : ℝ → ℝ} (hf : Continuous f)
    (hi : AllMoments f) (hz : {x | f x = 0}.Finite)
    (horth : ∀ p : ℝ[X], p.degree < (m : WithBot ℕ) → (∫ x, p.eval x * f x) = 0) :
    ∃ S : Finset ℝ, S.card = m ∧ ∀ r ∈ S, Crosses f r := by
  classical
  induction m generalizing f with
  | zero => exact ⟨∅,rfl,by simp⟩
  | succ m ih =>
    have hnon : ∃ x, f x ≠ 0 := by
      by_contra! h
      exact Set.infinite_univ (hz.subset (fun x _ => h x))
    have h0 := horth 1 (by rw [degree_one]; exact WithBot.coe_lt_coe.mpr (Nat.zero_lt_succ m))
    have h0' : (∫ x, f x) = 0 := by simpa using h0
    have hi' : Integrable f := by simpa using hi 1
    obtain ⟨hp,hn⟩ := integral_zero_both_signs hf hi' hnon h0'
    obtain ⟨r,hr⟩ := exists_crossing hf hz hp hn
    let g (u : ℝ) := (u-r)*f u
    have hg : Continuous g := (continuous_id.sub continuous_const).mul hf
    have hgi : AllMoments g := by
      intro p
      have he : (fun x => p.eval x * g x) = (fun x => (p*(X-C r)).eval x * f x) := by
        funext x
        simp [g,mul_assoc]
      rw [he]; exact hi _
    have hgz : {u | g u = 0}.Finite := by
      refine ((Set.finite_singleton r).union hz).subset ?_
      intro x hx
      rcases mul_eq_zero.mp hx with h | h
      · exact Or.inl (sub_eq_zero.mp h)
      · exact Or.inr h
    have hgo : ∀ p : ℝ[X], p.degree < (m : WithBot ℕ) → (∫ x, p.eval x * g x) = 0 := by
      intro p hp
      have hd : (p*(X-C r)).degree < ((m+1 : ℕ) : WithBot ℕ) := by
        by_cases he : p = 0
        · subst p; rw [zero_mul,degree_zero]; exact WithBot.bot_lt_coe _
        · have hne : p*(X-C r) ≠ 0 := mul_ne_zero he (X_sub_C_ne_zero r)
          rw [degree_eq_natDegree hne, natDegree_mul he (X_sub_C_ne_zero r), natDegree_X_sub_C]
          rw [degree_eq_natDegree he] at hp
          exact WithBot.coe_lt_coe.mpr (Nat.add_lt_add_right (WithBot.coe_lt_coe.mp hp) 1)
      simpa only [g,eval_mul,eval_sub,eval_X,eval_C,mul_assoc] using horth (p*(X-C r)) hd
    obtain ⟨S,hS,hroots⟩ := ih hg hgi hgz hgo
    have hnmem : r ∉ S := fun h => crossing_removed hr (hroots r h)
    refine ⟨insert r S,by rw [Finset.card_insert_of_not_mem hnmem,hS],?_⟩
    intro z hz
    rcases Finset.mem_insert.mp hz with rfl | hz
    · exact hr
    · exact crossing_other (r := r) (fun e => hnmem (e ▸ hz)) (hroots z hz)

end Cyclo
