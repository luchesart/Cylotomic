import Cyclo.Identity

/-! Integer lists use increasing degree. The computational operations below are independent
of the abstract implementation of polynomials in mathlib. Their correctness is proved by
evaluation or by identities in ℝ[X]. -/
namespace Cyclo.Cert
open Polynomial

noncomputable def horner : List ℤ → ℝ → ℝ
  | [], _ => 0
  | a :: l, x => a + x * horner l x

noncomputable def poly : List ℤ → ℝ[X]
  | [] => 0
  | a :: l => C (a : ℝ) + X * poly l

theorem eval_poly (l : List ℤ) (x : ℝ) : (poly l).eval x = horner l x := by
  induction l with
  | nil => simp [poly, horner]
  | cons a l ih => simp [poly, horner, ih]

def add : List ℤ → List ℤ → List ℤ
  | [], r => r
  | l, [] => l
  | a::l, b::r => (a+b) :: add l r

def scale (a : ℤ) (l : List ℤ) := l.map (a * ·)

theorem poly_add (l r : List ℤ) : poly (add l r) = poly l + poly r := by
  induction l generalizing r with
  | nil => simp [add,poly]
  | cons a l ih =>
    cases r with
    | nil => simp [add,poly]
    | cons b r => simp [add,poly,ih,mul_add,add_assoc,add_left_comm,add_comm]

theorem poly_scale (a : ℤ) (l : List ℤ) : poly (scale a l) = C (a : ℝ) * poly l := by
  induction l with
  | nil => simp [scale,poly]
  | cons b l ih =>
    change C (((a*b : ℤ):ℝ)) + X * poly (scale a l) = C (a:ℝ) * (C (b:ℝ) + X * poly l)
    rw [Int.cast_mul, map_mul, ih]
    ring

def times : List ℤ → List ℤ → List ℤ
  | [], _ => []
  | [a], r => scale a r
  | a :: b :: l, r => add (scale a r) (0 :: times (b :: l) r)

theorem poly_times (l r : List ℤ) : poly (times l r) = poly l * poly r := by
  match l with
  | [] => simp [times,poly]
  | [a] => simp [times,poly,poly_scale]
  | a::b::l =>
    rw [times,poly_add,poly_scale]
    change _ + (C ((0:ℤ):ℝ) + X* poly (times (b::l) r)) = (C (a:ℝ)+ X*poly (b::l))*poly r
    rw [poly_times (b::l) r]
    simp
    ring

def stretch (k : ℕ) : List ℤ → List ℤ
  | [] => []
  | [a] => [a]
  | a :: b :: l => a :: (List.replicate (k-1) 0 ++ stretch k (b::l))

theorem poly_zeroPrefix (k : ℕ) (l : List ℤ) : poly (List.replicate k 0 ++ l) =
    X^k * poly l := by
  induction k with
  | zero => simp
  | succ k ih => simp [List.replicate_succ,poly,ih,pow_succ']; ring

theorem poly_stretch (k : ℕ) (hk : 0 < k) (l : List ℤ) :
    poly (stretch k l) = expand ℝ k (poly l) := by
  match l with
  | [] => simp [stretch,poly]
  | [a] => simp [stretch,poly]
  | a::b::l =>
    rw [stretch]
    change C (a:ℝ) + X*poly (List.replicate (k-1) 0 ++ stretch k (b::l)) =
      expand ℝ k (C (a:ℝ)+X*poly (b::l))
    rw [poly_zeroPrefix, poly_stretch k hk (b::l), ← mul_assoc, ← pow_succ',
      Nat.sub_add_cancel hk]
    simp

theorem prime_step {n q : ℕ} (hq : q.Prime) (hdiv : ¬ q ∣ n) (l v : List ℤ)
    (hbase : poly l = cyclotomic n ℝ) (hcheck : times v l = stretch q l) :
    poly v = cyclotomic (n*q) ℝ := by
  apply mul_right_cancel₀ (cyclotomic_ne_zero n ℝ)
  rw [← cyclotomic_expand_eq_cyclotomic_mul hq hdiv, ← hbase, ← poly_times, hcheck,
    poly_stretch q hq.pos]

def weighted (k : ℕ) : List ℤ → List ℤ
  | [] => []
  | a::l => ((k:ℤ)*a) :: weighted (k+1) l

theorem poly_weighted (k : ℕ) (l : List ℤ) :
    poly (weighted k l) = C (k:ℝ) * poly l + X * (poly l).derivative := by
  induction l generalizing k with
  | nil => simp [poly,weighted]
  | cons a l ih =>
    simp [poly,weighted,ih,derivative_mul, mul_add]
    ring

theorem poly_derivative (a : ℤ) (l : List ℤ) :
    poly (weighted 1 l) = (poly (a::l)).derivative := by
  simp [poly_weighted,poly,derivative_mul]

theorem horner_add (l r : List ℤ) (x : ℝ) : horner (add l r) x = horner l x + horner r x := by
  simpa [eval_poly] using congrArg (Polynomial.eval x) (poly_add l r)

theorem horner_scale (a : ℤ) (l : List ℤ) (x : ℝ) : horner (scale a l) x = (a:ℝ) * horner l x := by
  simpa [eval_poly] using congrArg (Polynomial.eval x) (poly_scale a l)

/-- Homogeneous Horner evaluation in ℤ[X], tracking the numerator and a power of 1+X. -/
def homog (s : ℤ) : List ℤ → List ℤ × List ℤ
  | [] => ([], [1])
  | [a] => ([a], [1])
  | a :: b :: l =>
    let prev := homog s (b::l)
    let den := add prev.2 (0::prev.2)
    (add (scale a den) (0::scale s prev.1), den)

theorem horner_homog (s : ℤ) (l : List ℤ) (t : ℝ) (ht : 1+t ≠ 0) :
    horner (homog s l).1 t = (1+t)^(l.length-1) * horner l ((s:ℝ)*t/(1+t)) ∧
    horner (homog s l).2 t = (1+t)^(l.length-1) := by
  match l with
  | [] => simp [homog,horner]
  | [a] => simp [homog,horner]
  | a::b::l =>
    rcases horner_homog s (b::l) t ht with ⟨h1,h2⟩
    simp only [List.length_cons, Nat.add_sub_cancel] at h1 h2 ⊢
    rw [homog]
    simp only [horner_add, horner_scale, horner, Int.cast_zero,zero_add,h2,h1]
    constructor
    · rw [pow_succ]
      field_simp
      ring
    · rw [pow_succ]
      ring


/-- Scaled rational Horner evaluation with no division in the integer computation. -/
def ratPair (a b : ℤ) : List ℤ → ℤ × ℤ
  | [] => (0,1)
  | c::l =>
    let prev := ratPair a b l
    (c * b * prev.2 + a * prev.1, b * prev.2)

theorem ratPair_sound (a b : ℤ) (hb : b ≠ 0) (l : List ℤ) :
    ((ratPair a b l).1 : ℝ) = (b:ℝ)^l.length * horner l ((a:ℝ)/b) ∧
    ((ratPair a b l).2 : ℝ) = (b:ℝ)^l.length := by
  induction l with
  | nil => simp [ratPair,horner]
  | cons c l ih =>
    have hb' : (b:ℝ) ≠ 0 := by exact_mod_cast hb
    simp only [ratPair,Int.cast_add,Int.cast_mul,ih.1,ih.2,List.length_cons,pow_succ,horner]
    constructor
    · field_simp
      ring
    · ring

def bracket (l : List ℤ) (a : ℤ) (b : ℤ) : Bool :=
  decide ((ratPair a b l).1 * (ratPair (a+1) b l).1 < 0)

theorem bracket_sound (l : List ℤ) (a b : ℤ) (hb : 0 < b) (h : bracket l a b = true) :
    horner l ((a:ℝ)/b) * horner l (((a:ℝ)+1)/b) < 0 := by
  have hi : (ratPair a b l).1 * (ratPair (a+1) b l).1 < 0 := of_decide_eq_true h
  have hr : ((ratPair a b l).1 : ℝ) * ((ratPair (a+1) b l).1 : ℝ) < 0 := by exact_mod_cast hi
  rw [(ratPair_sound a b hb.ne' l).1,(ratPair_sound (a+1) b hb.ne' l).1] at hr
  push_cast at hr
  have hb' : 0 < (b:ℝ) := by exact_mod_cast hb
  have hb2 := mul_pos (pow_pos hb' l.length) (pow_pos hb' l.length)
  rw [mul_mul_mul_comm] at hr
  exact neg_of_mul_neg_right hr hb2.le

end Cyclo.Cert
