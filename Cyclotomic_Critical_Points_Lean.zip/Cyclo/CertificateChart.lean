import Cyclo.CertificateData
import Cyclo.Charts
import Cyclo.Variation

namespace Cyclo.Cert
open Polynomial Set Real
open scoped Polynomial

theorem series_eq_horner (A : List ℤ) (n : ℤ) (u : ℝ) :
    series A n u = exp ((n:ℝ)*u) * horner A (exp u) := by
  induction A generalizing n with
  | nil => simp [series, horner]
  | cons a A ih =>
    simp [series, horner, ih, add_mul, exp_add]
    ring

/-- A sign certificate for a homographic transform gives both a distinct-root
upper bound and simplicity if disjoint brackets attain that bound. -/
theorem chart_certificate (D : ℝ[X]) (s : ℝ) (hs : s = 1 ∨ s = -1) (A : List ℤ)
    (d : ℕ) (sg k : ℤ) (ks : List ℤ)
    (hp : ∀ t : ℝ, 0<t → horner A t = (1+t)^d * D.eval (s*t/(1+t)))
    (h1 : ∀ a ∈ applyTilts (scale sg A) (k::ks), 0 ≤ a)
    (h2 : ∃ a ∈ applyTilts (scale sg A) (k::ks), 0 < a) :
    RootCap (signedUnitInterval s) D.eval (ks.length+1) ∧
    (∀ T : Finset ℝ, (∀ x ∈ T, x ∈ signedUnitInterval s ∧ D.eval x=0) →
      T.card=ks.length+1 → ∀ x ∈ signedUnitInterval s, D.eval x=0 → D.rootMultiplicity x=1) := by
  let w (u : ℝ) := (sg:ℝ) * (1+exp u)^d
  have hw : Differentiable ℝ w := by dsimp [w]; fun_prop
  have hid : series (scale sg A) 0 = (fun u => w u * D.eval (logisticChart s u)) := by
    funext u
    simp [series_eq_horner, horner_scale, hp _ (exp_pos _), logisticChart, w, mul_assoc]
  constructor
  · apply rootCap_of_weighted_chart (w:=w) (logisticChart_surjOn hs)
    rw [← hid]
    exact cap_of_tilts _ _ h1 h2
  · intro T ht hcard x hx hx0
    obtain ⟨U, hu, hus⟩ := chart_witnesses hs D T ht
    apply simple_on_logistic_interval hs D hw _ hx hx0
    intro u hz
    rw [← hid]
    apply simple_of_tilts _ k ks h1 h2 U
    · intro v hv
      rw [hid]
      simp [hus v hv]
    · exact hu.trans hcard
    · rw [hid]
      simp [hz]

end Cyclo.Cert
