import Cyclo.Binary

/-! # Lifting real critical points through prime powers and reflection

The identities in this file concern the actual real cyclotomic polynomials.
Exponents are indexed by their excess over the squarefree exponent one.
-/
noncomputable section
open Polynomial
namespace Cyclo.Lifts

theorem repeated_prime {p n : ℕ} (hp : p.Prime) (hd : p ∣ n) (a : ℕ) :
    cyclotomic (n * p^a) ℝ = expand ℝ (p^a) (cyclotomic n ℝ) := by
  induction a with
  | zero => simp
  | succ a ih =>
    rw [pow_succ, ← Nat.mul_assoc, ← cyclotomic_expand_eq_cyclotomic hp (dvd_mul_of_dvd_left hd (p^a)), ih,
      expand_expand, Nat.mul_comm p (p^a)]

private theorem reflect_expand (F : ℝ[X]) {p : ℕ} (ho : Odd p) :
    expand ℝ p (F.comp (-X)) = (expand ℝ p F).comp (-X) := by
  simp only [expand_eq_comp_X_pow, comp_assoc, neg_comp, X_comp, pow_comp, ho.neg_pow]

private theorem extend_reflection {n p : ℕ} (hp : p.Prime) (ho : Odd p) (hd : ¬p ∣ n)
    (c : ℝ) (h : cyclotomic (2*n) ℝ = (cyclotomic n ℝ).comp (-X) * C c) :
    cyclotomic (2*(n*p)) ℝ = (cyclotomic (n*p) ℝ).comp (-X) := by
  have h2 : ¬ p ∣ 2 := by
    intro h'
    rcases (Nat.dvd_prime Nat.prime_two).mp h' with h1|hp2
    · exact hp.ne_one h1
    · exact ho.not_two_dvd_nat (hp2 ▸ dvd_refl _)
  have hd' : ¬p ∣ 2*n := by simpa [hp.dvd_mul, h2] using hd
  apply mul_right_cancel₀ (cyclotomic_ne_zero (2*n) ℝ)
  rw [← Nat.mul_assoc, ← cyclotomic_expand_eq_cyclotomic_mul hp hd', h, map_mul, expand_C,
    reflect_expand _ ho, cyclotomic_expand_eq_cyclotomic_mul hp hd, mul_comp, mul_assoc]

theorem reflect_two_primes {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hop : Odd p)
    (hoq : Odd q) (hlt : p < q) :
    cyclotomic (2*(p*q)) ℝ = (cyclotomic (p*q) ℝ).comp (-X) := by
  have hbase : cyclotomic (2*1) ℝ = (cyclotomic 1 ℝ).comp (-X) * C (-1) := by
    simp [cyclotomic_two, sub_comp, add_comm]
  have hp' := extend_reflection hp hop hp.not_dvd_one (-1) hbase
  simp only [Nat.one_mul] at hp'
  apply extend_reflection hq hoq (Nat.not_dvd_of_pos_of_lt hp.pos hlt) 1
  simpa using hp'

private theorem repeated_binary {p q n : ℕ} (hp : p.Prime) (hq : q.Prime)
    (hp' : p ∣ n) (hq' : q ∣ n) (a b : ℕ) :
    cyclotomic (n*p^a*q^b) ℝ = expand ℝ (p^a*q^b) (cyclotomic n ℝ) := by
  rw [repeated_prime hq (dvd_mul_of_dvd_left hq' (p^a)), repeated_prime hp hp', expand_expand, Nat.mul_comm (q^b)]

theorem odd_binary_expansion {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (a b : ℕ) :
    cyclotomic (p^(a+1)*q^(b+1)) ℝ =
      expand ℝ (p^a*q^b) (cyclotomic (p*q) ℝ) := by
  rw [show p^(a+1)*q^(b+1) = p*q*p^a*q^b by rw [pow_succ, pow_succ]; ring]
  exact repeated_binary hp hq (dvd_mul_right _ _) (dvd_mul_left _ _) a b

theorem even_binary_expansion {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hop : Odd p)
    (hoq : Odd q) (hlt : p < q) (e a b : ℕ) :
    cyclotomic (2^(e+1)*p^(a+1)*q^(b+1)) ℝ =
      expand ℝ (2^e*p^a*q^b) ((cyclotomic (p*q) ℝ).comp (-X)) := by
  let n := 2*(p*q)
  have h2 : 2 ∣ n := dvd_mul_right _ _
  have hp' : p ∣ n*2^e := dvd_mul_of_dvd_left (dvd_mul_of_dvd_right (dvd_mul_right _ _) _) _
  have hq' : q ∣ n*2^e := dvd_mul_of_dvd_left (dvd_mul_of_dvd_right (dvd_mul_left _ _) _) _
  rw [show 2^(e+1)*p^(a+1)*q^(b+1) = n*2^e*p^a*q^b by dsimp [n]; simp only [pow_succ]; ring,
    repeated_binary hp hq hp' hq', repeated_prime Nat.prime_two h2, expand_expand]
  rw [show p^a*q^b*2^e = 2^e*p^a*q^b by ring, ← reflect_two_primes hp hq hop hoq hlt]

theorem expand_derivative_eval (F : ℝ[X]) (h : ℕ) (x : ℝ) :
    (expand ℝ h F).derivative.eval x = F.derivative.eval (x^h) * (h * x^(h-1)) := by
  simp [derivative_expand, expand_eval]

theorem reflect_derivative_eval (F : ℝ[X]) (x : ℝ) :
    (F.comp (-X)).derivative.eval x = - F.derivative.eval (-x) := by
  simp [derivative_comp, eval_comp]

theorem odd_binary_critical_iff {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (a b : ℕ)
    {x : ℝ} (hx : x ≠ 0) :
    (cyclotomic (p^(a+1)*q^(b+1)) ℝ).derivative.eval x = 0 ↔
    (cyclotomic (p*q) ℝ).derivative.eval (x^(p^a*q^b)) = 0 := by
  rw [odd_binary_expansion hp hq, expand_derivative_eval]
  simp [hx, hp.ne_zero, hq.ne_zero]

theorem even_binary_critical_iff {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hop : Odd p)
    (hoq : Odd q) (hlt : p < q) (e a b : ℕ) {x : ℝ} (hx : x ≠ 0) :
    (cyclotomic (2^(e+1)*p^(a+1)*q^(b+1)) ℝ).derivative.eval x = 0 ↔
    (cyclotomic (p*q) ℝ).derivative.eval (-(x^(2^e*p^a*q^b))) = 0 := by
  rw [even_binary_expansion hp hq hop hoq hlt, expand_derivative_eval, reflect_derivative_eval]
  simp [hx, hp.ne_zero, hq.ne_zero]


private theorem mult_pow (P : ℝ[X]) (hP : P ≠ 0) (x : ℝ) (m : ℕ) :
    (P^m).rootMultiplicity x = m * P.rootMultiplicity x := by
  induction m with
  | zero => simp
  | succ m ih =>
    rw [pow_succ, rootMultiplicity_mul (mul_ne_zero (pow_ne_zero _ hP) hP), ih, Nat.succ_mul]

private theorem mult_one_of_eval {P : ℝ[X]} {x : ℝ}
    (he : P.eval x = 0) (hd : P.derivative.eval x ≠ 0) : P.rootMultiplicity x = 1 := by
  have hn : P ≠ 0 := by intro hz; simp [hz] at hd
  have hr : P.IsRoot x := he
  have hpos := (rootMultiplicity_pos hn).2 hr
  have h0 : P.derivative.rootMultiplicity x = 0 := rootMultiplicity_eq_zero hd
  have H := derivative_rootMultiplicity_of_root hr
  omega

/-- Composition by a polynomial with nonvanishing derivative preserves exact multiplicities. -/
theorem rootMultiplicity_comp_regular (F Q : ℝ[X]) (x : ℝ) (hd : Q.derivative.eval x ≠ 0) :
    (F.comp Q).rootMultiplicity x = F.rootMultiplicity (Q.eval x) := by
  classical
  by_cases hf : F = 0
  · simp [hf]
  let y := Q.eval x
  let E := Q - C y
  have hE : E.derivative.eval x ≠ 0 := by simpa [E] using hd
  have hen : E ≠ 0 := by intro h; simp [h] at hE
  have hEm : E.rootMultiplicity x = 1 := mult_one_of_eval (by simp [E,y]) hE
  obtain ⟨R, hR, hdiv⟩ := F.exists_eq_pow_rootMultiplicity_mul_and_not_dvd hf y
  have hRval : (R.comp Q).eval x ≠ 0 := by
    rw [eval_comp]; exact fun e => hdiv (dvd_iff_isRoot.mpr e)
  have hRn : R.comp Q ≠ 0 := by intro h; simp [h] at hRval
  have hfac : F.comp Q = E ^ F.rootMultiplicity y * R.comp Q := by
    conv_lhs => rw [hR, mul_comp, pow_comp]
    simp [E, sub_comp]
  rw [hfac, rootMultiplicity_mul (mul_ne_zero (pow_ne_zero _ hen) hRn), mult_pow _ hen,
    hEm, rootMultiplicity_eq_zero hRval, Nat.mul_one, Nat.add_zero]

theorem derivativeMultiplicity_comp_regular (F Q : ℝ[X]) (x : ℝ)
    (hd : Q.derivative.eval x ≠ 0) :
    (F.comp Q).derivative.rootMultiplicity x = F.derivative.rootMultiplicity (Q.eval x) := by
  by_cases hz : F.derivative.comp Q = 0
  · rw [← rootMultiplicity_comp_regular F.derivative Q x hd, derivative_comp, hz, mul_zero]
  have hQ : Q.derivative ≠ 0 := by intro e; simp [e] at hd
  rw [derivative_comp, rootMultiplicity_mul (mul_ne_zero hQ hz),
    rootMultiplicity_eq_zero hd, Nat.zero_add, rootMultiplicity_comp_regular F.derivative Q x hd]

theorem binary_derivative_zero_value {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hlt : p < q) :
    (cyclotomic (p*q) ℝ).derivative.eval 0 = -1 := by
  haveI : Fact p.Prime := ⟨hp⟩
  have h1 : (cyclotomic p ℝ).derivative.eval 0 = 1 := by
    rw [← coeff_zero_eq_eval_zero, coeff_derivative, cyclotomic_prime]
    simp [finset_sum_coeff, coeff_X_pow, hp.one_lt]
  have hprod : 1 < p*q := by nlinarith [hp.one_lt,hq.one_lt]
  have hconst : (cyclotomic (p*q) ℝ).eval 0 = 1 := by
    rw [← coeff_zero_eq_eval_zero, cyclotomic_coeff_zero ℝ hprod]
  have hbase : (cyclotomic p ℝ).eval 0 = 1 := by
    rw [← coeff_zero_eq_eval_zero, cyclotomic_coeff_zero ℝ hp.one_lt]
  have he := congrArg (fun F : ℝ[X] => F.derivative.eval 0)
    (cyclotomic_expand_eq_cyclotomic_mul hq (Nat.not_dvd_of_pos_of_lt hp.pos hlt) ℝ)
  change (expand ℝ q (cyclotomic p ℝ)).derivative.eval 0 =
    ((cyclotomic (p*q) ℝ)*(cyclotomic p ℝ)).derivative.eval 0 at he
  have hqm : q-1 ≠ 0 := by have := hq.one_lt; omega
  simp only [expand_derivative_eval, zero_pow hq.ne_zero, zero_pow hqm, mul_zero,
    derivative_mul, eval_add, eval_mul, h1, hbase, hconst] at he
  linarith

theorem origin_mult (F : ℝ[X]) {h : ℕ} (hh : h ≠ 0) (hf : F.derivative.eval 0 ≠ 0) :
    (expand ℝ h F).derivative.rootMultiplicity 0 = h-1 := by
  let G := expand ℝ h F.derivative * C (h : ℝ)
  have he : G.eval 0 ≠ 0 := by simpa [G, expand_eval, hh] using mul_ne_zero hf (by exact_mod_cast hh : (h : ℝ) ≠ 0)
  have hG : G ≠ 0 := by intro e; simp [e] at he
  have hx : ((X : ℝ[X])^(h-1)) ≠ 0 := pow_ne_zero _ X_ne_zero
  rw [derivative_expand, ← C_eq_natCast, ← mul_assoc]
  change (G * X^(h-1)).rootMultiplicity 0 = h-1
  rw [rootMultiplicity_mul (mul_ne_zero hG hx), rootMultiplicity_eq_zero he, Nat.zero_add]
  simpa using rootMultiplicity_X_sub_C_pow (0 : ℝ) (h-1)

theorem odd_origin_mult {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hlt : p < q) (a b : ℕ) :
    (cyclotomic (p^(a+1)*q^(b+1)) ℝ).derivative.rootMultiplicity 0 = p^a*q^b-1 := by
  rw [odd_binary_expansion hp hq]
  apply origin_mult (hh := by simp [hp.ne_zero,hq.ne_zero])
  rw [binary_derivative_zero_value hp hq hlt]; norm_num

theorem even_origin_mult {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hop : Odd p)
    (hoq : Odd q) (hlt : p < q) (e a b : ℕ) :
    (cyclotomic (2^(e+1)*p^(a+1)*q^(b+1)) ℝ).derivative.rootMultiplicity 0 = 2^e*p^a*q^b-1 := by
  rw [even_binary_expansion hp hq hop hoq hlt]
  apply origin_mult (hh := by simp [hp.ne_zero,hq.ne_zero])
  rw [reflect_derivative_eval, neg_zero, binary_derivative_zero_value hp hq hlt]; norm_num


theorem expansion_mult_nonzero (F : ℝ[X]) {h : ℕ} (hh : h ≠ 0) {x : ℝ} (hx : x ≠ 0) :
    (expand ℝ h F).derivative.rootMultiplicity x = F.derivative.rootMultiplicity (x^h) := by
  rw [expand_eq_comp_X_pow, derivativeMultiplicity_comp_regular]
  · simp
  · simp [derivative_pow, hx, hh]

theorem reflection_mult (F : ℝ[X]) (x : ℝ) :
    (F.comp (-X)).derivative.rootMultiplicity x = F.derivative.rootMultiplicity (-x) := by
  rw [derivativeMultiplicity_comp_regular] <;> simp

theorem odd_mult_nonzero {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (a b : ℕ) {x : ℝ}
    (hx : x ≠ 0) : (cyclotomic (p^(a+1)*q^(b+1)) ℝ).derivative.rootMultiplicity x =
      (cyclotomic (p*q) ℝ).derivative.rootMultiplicity (x^(p^a*q^b)) := by
  rw [odd_binary_expansion hp hq, expansion_mult_nonzero (hh := by simp [hp.ne_zero,hq.ne_zero]) _ hx]

theorem even_mult_nonzero {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hop : Odd p)
    (hoq : Odd q) (hlt : p < q) (e a b : ℕ) {x : ℝ} (hx : x ≠ 0) :
    (cyclotomic (2^(e+1)*p^(a+1)*q^(b+1)) ℝ).derivative.rootMultiplicity x =
    (cyclotomic (p*q) ℝ).derivative.rootMultiplicity (-(x^(2^e*p^a*q^b))) := by
  rw [even_binary_expansion hp hq hop hoq hlt,
    expansion_mult_nonzero (hh := by simp [hp.ne_zero,hq.ne_zero]) _ hx, reflection_mult]

def signedArg (negative : Bool) (r : ℝ) := if negative then -r else r

/-- The positive radius parametrizes one open half-line. Each critical point on that side
is counted once, with no repeated copies and without the origin. -/
def criticalRadii (n : ℕ) (negative : Bool) :=
  {r : ℝ // 0 < r ∧ (cyclotomic n ℝ).derivative.eval (signedArg negative r) = 0}

def signedCount (n : ℕ) (negative : Bool) := Nat.card (criticalRadii n negative)

private theorem power_card {n m h : ℕ} {s t : Bool} (hh : h ≠ 0)
    (H : ∀ r : ℝ, 0 < r →
      ((cyclotomic n ℝ).derivative.eval (signedArg s r) = 0 ↔
       (cyclotomic m ℝ).derivative.eval (signedArg t (r^h)) = 0)) : signedCount n s = signedCount m t := by
  let f : criticalRadii n s → criticalRadii m t := fun z =>
    ⟨z.val ^ h, pow_pos z.property.1 _, (H _ z.property.1).mp z.property.2⟩
  apply Nat.card_congr (Equiv.ofBijective f ⟨?_,?_⟩)
  · intro x y hxy
    exact Subtype.ext ((pow_left_inj₀ x.property.1.le y.property.1.le hh).mp (congrArg Subtype.val hxy))
  · rintro ⟨y,hy,hz⟩
    let r := y ^ ((h : ℝ)⁻¹)
    have hr : 0 < r := Real.rpow_pos_of_pos hy _
    have he : r^h = y := Real.rpow_inv_natCast_pow hy.le hh
    exact ⟨⟨r,hr,(H r hr).mpr (he ▸ hz)⟩,Subtype.ext he⟩

theorem odd_binary_signed_count {p q : ℕ} (hp : p.Prime) (hq : q.Prime)
    (hop : Odd p) (hoq : Odd q) (a b : ℕ) (s : Bool) :
    signedCount (p^(a+1)*q^(b+1)) s = signedCount (p*q) s := by
  apply power_card (h := p^a*q^b) (by simp [hp.ne_zero, hq.ne_zero])
  intro r hr
  have hOdd : Odd (p^a*q^b) := hop.pow.mul hoq.pow
  cases s <;> simp only [signedArg, Bool.false_eq_true, if_false, if_true]
  · exact odd_binary_critical_iff hp hq a b hr.ne'
  · simpa only [hOdd.neg_pow] using odd_binary_critical_iff hp hq a b (neg_ne_zero.mpr hr.ne')

theorem single_two_binary_signed_count {p q : ℕ} (hp : p.Prime) (hq : q.Prime)
    (hop : Odd p) (hoq : Odd q) (hlt : p < q) (a b : ℕ) (s : Bool) :
    signedCount (2*p^(a+1)*q^(b+1)) s = signedCount (p*q) (!s) := by
  apply power_card (h := p^a*q^b) (by simp [hp.ne_zero, hq.ne_zero])
  intro r hr
  have hOdd : Odd (p^a*q^b) := hop.pow.mul hoq.pow
  cases s
  · simpa [signedArg] using even_binary_critical_iff hp hq hop hoq hlt 0 a b hr.ne'
  · simpa [signedArg,hOdd.neg_pow] using even_binary_critical_iff hp hq hop hoq hlt 0 a b (neg_ne_zero.mpr hr.ne')

theorem higher_two_binary_signed_count {p q : ℕ} (hp : p.Prime) (hq : q.Prime)
    (hop : Odd p) (hoq : Odd q) (hlt : p < q) (e a b : ℕ) (s : Bool) :
    signedCount (2^(e+2)*p^(a+1)*q^(b+1)) s = signedCount (p*q) true := by
  apply power_card (h := 2^(e+1)*p^a*q^b) (by simp [hp.ne_zero, hq.ne_zero])
  intro r hr
  have hEven : Even (2^(e+1)*p^a*q^b) :=
    (((even_two (α := ℕ)).pow_of_ne_zero (Nat.succ_ne_zero e)).mul_right _).mul_right _
  cases s
  · simpa only [signedArg, Bool.false_eq_true, if_false, if_true] using
      even_binary_critical_iff hp hq hop hoq hlt (e+1) a b hr.ne'
  · simpa only [signedArg, if_true, hEven.neg_pow] using
      even_binary_critical_iff hp hq hop hoq hlt (e+1) a b (neg_ne_zero.mpr hr.ne')

/-- Evaluation of the two base counts from an ordered, exhaustive triple of critical points. -/
theorem counts_of_binary_roots {n : ℕ} {a b c : ℝ} (hab : a < b) (hb : b < 0) (hc : 0 < c)
    (H : ∀ x, (cyclotomic n ℝ).derivative.eval x = 0 ↔ x = a ∨ x = b ∨ x = c) :
    signedCount n true = 2 ∧ signedCount n false = 1 := by
  classical
  have ha : a < 0 := hab.trans hb
  let xa : criticalRadii n true := ⟨-a, neg_pos.mpr ha, by simp [signedArg, H]⟩
  let xb : criticalRadii n true := ⟨-b, neg_pos.mpr hb, by simp [signedArg, H]⟩
  have hne : xa ≠ xb := fun e => hab.ne (neg_injective (congrArg Subtype.val e))
  have ex (x : criticalRadii n true) : x = xa ∨ x = xb := by
    have hx := (H _).mp x.property.2
    change -x.val = a ∨ -x.val = b ∨ -x.val = c at hx
    rcases hx with ha'|hb'|hc'
    · exact Or.inl (Subtype.ext (by change x.val = -a; linarith))
    · exact Or.inr (Subtype.ext (by change x.val = -b; linarith))
    · linarith [x.property.1]
  let f : Bool → criticalRadii n true := fun d => if d then xa else xb
  refine ⟨?_,?_⟩
  · have he : Function.Bijective f := by
      constructor
      · intro d e h; cases d <;> cases e <;> simp_all [f]
      · intro x; rcases ex x with rfl|rfl
        · exact ⟨true,rfl⟩
        · exact ⟨false,rfl⟩
    change Nat.card (criticalRadii n true) = 2
    rw [← Nat.card_congr (Equiv.ofBijective f he)]
    simp
  · haveI : Nonempty (criticalRadii n false) := ⟨⟨c,hc,by simp [signedArg,H]⟩⟩
    have eqc (x : criticalRadii n false) : x.val = c := by
      have hx := (H x.val).mp x.property.2
      rcases hx with e|e|e <;> linarith [x.property.1]
    haveI : Subsingleton (criticalRadii n false) := ⟨fun u v => Subtype.ext ((eqc u).trans (eqc v).symm)⟩
    exact Nat.card_unique


/-- Exact ordered pair (negative, positive), multiplicity at the origin,
and simplicity of every nonzero critical point, for all powers in the family
2^e * p^(a+1) * q^(b+1). -/
theorem prime_power_family {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hlt : p < q)
    (hop : Odd p) (hoq : Odd q) (e a b : ℕ) :
    let n := 2^e * p^(a+1) * q^(b+1)
    let h := 2^(e-1) * p^a * q^b
    let D := (cyclotomic n ℝ).derivative
    (signedCount n true, signedCount n false) =
      (if e = 0 then (2,1) else if e = 1 then (1,2) else (2,2)) ∧
    D.rootMultiplicity 0 = h-1 ∧
    ∀ x : ℝ, x ≠ 0 → D.eval x = 0 → D.rootMultiplicity x = 1 := by
  obtain ⟨r,s,t,_,hrs,hs,ht,_,H,HD⟩ := Cyclo.Binary.binary_exact hp hq hlt hop hoq
  have hc := counts_of_binary_roots hrs hs ht H
  have hreg (x : ℝ) (hx : (cyclotomic (p*q) ℝ).derivative.eval x = 0) :
      (cyclotomic (p*q) ℝ).derivative.rootMultiplicity x = 1 := mult_one_of_eval hx (HD x hx)
  dsimp only
  cases e with
  | zero =>
    simp only [pow_zero, one_mul, if_true, Nat.zero_sub]
    refine ⟨?_, odd_origin_mult hp hq hlt a b, ?_⟩
    · rw [odd_binary_signed_count hp hq hop hoq, odd_binary_signed_count hp hq hop hoq, hc.1,hc.2]
    · intro x hx hD
      rw [odd_mult_nonzero hp hq a b hx]
      exact hreg _ ((odd_binary_critical_iff hp hq a b hx).mp hD)
  | succ e =>
    refine ⟨?_, even_origin_mult hp hq hop hoq hlt e a b, ?_⟩
    · cases e with
      | zero =>
        change (signedCount (2*p^(a+1)*q^(b+1)) true, signedCount (2*p^(a+1)*q^(b+1)) false) = (1,2)
        simp only [single_two_binary_signed_count hp hq hop hoq hlt, Bool.not_true, Bool.not_false, hc.1, hc.2]
      | succ e =>
        simp only [Nat.succ_ne_zero, Nat.succ.injEq, if_false,
          higher_two_binary_signed_count hp hq hop hoq hlt, hc.1]
    · intro x hx hD
      rw [even_mult_nonzero hp hq hop hoq hlt e a b hx]
      exact hreg _ ((even_binary_critical_iff hp hq hop hoq hlt e a b hx).mp hD)

end Cyclo.Lifts
