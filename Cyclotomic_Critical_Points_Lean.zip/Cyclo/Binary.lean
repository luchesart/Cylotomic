import Mathlib

/-! Sign blocks in the two-prime case. The change of variable x = exp u turns
the Descartes bounds with one or two sign changes into monotonicity and Rolle
bounds on finite exponential sums. -/
namespace Cyclo.Binary
open Finset Polynomial Real

noncomputable section
def spectrum {ι : Type*} [Fintype ι] (w d : ι → ℝ) (u : ℝ) : ℝ :=
  ∑ i, w i * exp (d i * u)

theorem spectrum_hasDerivAt {ι : Type*} [Fintype ι] (w d : ι → ℝ) (u : ℝ) :
    HasDerivAt (spectrum w d) (spectrum (fun i => w i * d i) d u) u := by
  unfold spectrum
  apply HasDerivAt.sum
  intro i _
  convert (((hasDerivAt_id u).const_mul (d i)).exp.const_mul (w i)) using 1
  simp only [id_eq, mul_one]
  ring

theorem spectrum_shift {ι : Type*} [Fintype ι] (w d : ι → ℝ) (s u : ℝ) :
    spectrum w (fun i => d i - s) u = spectrum w d u * exp (-s * u) := by
  unfold spectrum
  rw [sum_mul]
  apply sum_congr rfl
  intro i _
  rw [mul_assoc, ← exp_add]
  congr 2
  ring

theorem spectrum_deriv_pos {ι : Type*} [Fintype ι] (w d : ι → ℝ)
    (h : ∀ i, 0 ≤ w i * d i) (hp : ∃ i, 0 < w i * d i) :
    ∀ u, 0 < deriv (spectrum w d) u := by
  intro u
  rw [(spectrum_hasDerivAt w d u).deriv]
  apply sum_pos'
  · intro i _
    exact mul_nonneg (h i) (exp_pos _).le
  · obtain ⟨i, hi⟩ := hp
    exact ⟨i, mem_univ _, mul_pos hi (exp_pos _)⟩

theorem spectrum_strictMono {ι : Type*} [Fintype ι] (w d : ι → ℝ)
    (h : ∀ i, 0 ≤ w i * d i) (hp : ∃ i, 0 < w i * d i) :
    StrictMono (spectrum w d) :=
  strictMono_of_deriv_pos (spectrum_deriv_pos w d h hp)

def geo (p : ℕ) (s u : ℝ) : ℝ := spectrum (fun _ : Fin p => 1) (fun j => s * j.val) u

theorem geo_eq_eval {p : ℕ} (hp : p.Prime) (s u : ℝ) :
    geo p s u = (cyclotomic p ℝ).eval (exp (s*u)) := by
  letI : Fact p.Prime := ⟨hp⟩
  rw [cyclotomic_prime, eval_finset_sum]
  simp only [eval_pow, eval_X]
  rw [← Fin.sum_univ_eq_sum_range]
  unfold geo spectrum
  apply sum_congr rfl
  intro i _
  rw [one_mul, ← exp_nat_mul]
  congr 1
  ring

theorem geo_pos {p : ℕ} (h : 0 < p) (s u : ℝ) : 0 < geo p s u := by
  unfold geo spectrum
  apply sum_pos'
  · intro i _
    positivity
  · exact ⟨⟨0,h⟩, mem_univ _, by simp⟩

theorem binary_geo_product {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hlt : p < q) (u : ℝ) :
    (cyclotomic (p*q) ℝ).eval (exp u) * geo p 1 u = geo p q u := by
  rw [geo_eq_eval hp, geo_eq_eval hp, one_mul, exp_nat_mul,
    ← expand_eval, cyclotomic_expand_eq_cyclotomic_mul hq (Nat.not_dvd_of_pos_of_lt hp.pos hlt)]
  simp

def pw (q : ℕ) {p : ℕ} (a : Fin p × Fin p) : ℝ := q * (a.1.val : ℝ) - a.2.val

def pd (q : ℕ) {p : ℕ} (a : Fin p × Fin p) : ℝ := q * (a.1.val : ℝ) + a.2.val

theorem positive_spectrum_slope {p q : ℕ} (hp : 1 < p) (hlt : p < q) :
    ∀ u, 0 < deriv (spectrum (pw q : Fin p × Fin p → ℝ) (fun a => pd q a - p)) u := by
  apply spectrum_deriv_pos
  · rintro ⟨j,i⟩
    unfold pw pd
    dsimp
    have hi : (i.val : ℝ) < p := by exact_mod_cast i.isLt
    have hq : (p : ℝ) < q := by exact_mod_cast hlt
    by_cases hz : j.val = 0
    · rw [hz]
      simp only [Nat.cast_zero, mul_zero, zero_add, zero_sub]
      exact mul_nonneg_of_nonpos_of_nonpos (neg_nonpos.mpr (Nat.cast_nonneg _)) (by linarith)
    · have hj : (1 : ℝ) ≤ j.val := by exact_mod_cast (Nat.one_le_iff_ne_zero.mpr hz)
      have hqpos : 0 ≤ (q : ℝ) := by positivity
      exact mul_nonneg (by nlinarith [mul_nonneg hqpos (sub_nonneg.mpr hj)]) (by
        nlinarith [mul_nonneg hqpos (sub_nonneg.mpr hj), Nat.cast_nonneg (α := ℝ) i.val])
  · let i : Fin p := ⟨1,hp⟩
    let j : Fin p := ⟨0, by omega⟩
    refine ⟨(j,i), ?_⟩
    have hp' : (1 : ℝ) < p := by exact_mod_cast hp
    simp [pw, pd, j, i]
    linarith

theorem positive_sign_blocks {p q : ℕ} (hp : 1 < p) (hlt : p < q) :
    StrictMono (spectrum (pw q : Fin p × Fin p → ℝ) (fun a => pd q a - p)) :=
  strictMono_of_deriv_pos (positive_spectrum_slope hp hlt)

def geoSlope (p : ℕ) (s u : ℝ) : ℝ :=
  spectrum (fun i : Fin p => s * i.val) (fun i => s * i.val) u

theorem geo_deriv (p : ℕ) (s u : ℝ) : HasDerivAt (geo p s) (geoSlope p s u) u := by
  simpa [geo, geoSlope] using spectrum_hasDerivAt (fun _ : Fin p => (1 : ℝ)) (fun i => s * i.val) u

theorem positive_numerator (p q : ℕ) (u : ℝ) :
    spectrum (pw q : Fin p × Fin p → ℝ) (pd q) u =
      geoSlope p q u * geo p 1 u - geo p q u * geoSlope p 1 u := by
  unfold spectrum pw pd geo geoSlope
  simp only [spectrum, one_mul, Fintype.sum_prod_type, sum_mul, mul_sum, ← sum_sub_distrib]
  rw [sum_comm]
  apply sum_congr rfl
  intro j _
  apply sum_congr rfl
  intro i _
  simp only [add_mul, exp_add]
  ring

theorem positive_derivative_numerator {p q : ℕ} (hp : p.Prime) (hq : q.Prime)
    (hlt : p < q) (u : ℝ) :
    spectrum (pw q : Fin p × Fin p → ℝ) (pd q) u =
      (cyclotomic (p*q) ℝ).derivative.eval (exp u) * exp u * (geo p 1 u)^2 := by
  let P := cyclotomic (p*q) ℝ
  have h₁ := (((P.hasDerivAt (exp u)).comp u (hasDerivAt_exp u)).mul (geo_deriv p 1 u))
  have heq : (fun v => (fun y => P.eval y) (exp v) * geo p 1 v) = geo p q :=
    funext (binary_geo_product hp hq hlt)
  change HasDerivAt (fun v => P.eval (exp v) * geo p 1 v) _ u at h₁
  rw [heq] at h₁
  have hd := h₁.unique (geo_deriv p q u)
  change P.derivative.eval (exp u) * exp u * geo p 1 u +
    P.eval (exp u) * geoSlope p 1 u = geoSlope p q u at hd
  rw [positive_numerator, ← hd, ← binary_geo_product hp hq hlt]
  dsimp [P]
  ring

/-- On the positive half-line the actual cyclotomic derivative has at most one zero. -/
theorem positive_critical_unique {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hlt : p < q)
    {a b : ℝ} (ha : 0 < a) (hb : 0 < b)
    (hA : (cyclotomic (p*q) ℝ).derivative.eval a = 0)
    (hB : (cyclotomic (p*q) ℝ).derivative.eval b = 0) : a = b := by
  have kill {r : ℝ} (hr : 0 < r) (hR : (cyclotomic (p*q) ℝ).derivative.eval r = 0) :
      spectrum (pw q : Fin p × Fin p → ℝ) (fun i => pd q i - p) (log r) = 0 := by
    rw [spectrum_shift, positive_derivative_numerator hp hq hlt, exp_log hr, hR]
    ring
  have h := (positive_sign_blocks hp.one_lt hlt).injective ((kill ha hA).trans (kill hb hB).symm)
  simpa [exp_log ha, exp_log hb] using congrArg exp h

/-- Exponents and coefficients after clearing the four logarithmic terms. -/
def nd (p q : ℝ) : Fin 15 → ℝ :=
  ![1, p, q, 1+p, 1+q, p+q, 1+p+q,
    p*q, p*q+1, p*q+p, p*q+q, p*q+1+p, p*q+1+q, p*q+p+q, p*q+1+p+q]

def nw (p q : ℝ) : Fin 15 → ℝ :=
  ![1, -p, -q, 1-p, 1-q, -p-q, 1-p-q,
    p*q, p*q+1, p*q-p, p*q-q, p*q+1-p, p*q+1-q, p*q-p-q, p*q+1-p-q]

private def dn (p q : ℝ) (i : Fin 15) := nd p q i - 1
private def wn (p q : ℝ) (i : Fin 15) := nw p q i * dn p q i

theorem negative_sign_blocks {p q : ℝ} (hp : 3 ≤ p) (hq : p < q) :
    StrictMono (spectrum (wn p q) (fun i => dn p q i - (p*q-2))) := by
  have hgap : 2 + p + q < p*q := by
    nlinarith [mul_nonneg (show 0 ≤ p-3 by linarith) (show 0 ≤ q-3 by linarith)]
  apply spectrum_strictMono
  · intro i
    fin_cases i <;> norm_num [wn, dn, nw, nd, Matrix.cons_val_succ] <;>
      first | apply mul_nonneg_of_nonpos_of_nonpos <;> first | apply mul_nonpos_of_nonpos_of_nonneg <;> linarith | linarith
            | apply mul_nonneg <;> first | apply mul_nonneg <;> linarith | linarith
            | apply mul_nonpos_of_nonneg_of_nonpos <;> first | apply mul_nonneg <;> linarith | linarith
  · refine ⟨1, ?_⟩
    norm_num [wn, dn, nw, nd, Matrix.cons_val_succ]
    apply mul_neg_of_pos_of_neg
    · apply mul_pos <;> linarith
    · linarith

theorem spectrum_deriv_unique {p q : ℝ} (hp : 3 ≤ p) (hq : p < q) {u v : ℝ}
    (hu : deriv (spectrum (nw p q) (dn p q)) u = 0)
    (hv : deriv (spectrum (nw p q) (dn p q)) v = 0) : u = v := by
  have kill {t : ℝ} (ht : deriv (spectrum (nw p q) (dn p q)) t = 0) :
      spectrum (wn p q) (fun i => dn p q i - (p*q-2)) t = 0 := by
    rw [spectrum_shift]
    rw [(spectrum_hasDerivAt _ _ t).deriv] at ht
    change spectrum (wn p q) (dn p q) t = 0 at ht
    simp [ht]
  exact (negative_sign_blocks hp hq).injective ((kill hu).trans (kill hv).symm)

/-- Exact signed-input identity for arbitrary distinct odd primes. -/
theorem negative_cyclotomic_product {p q : ℕ} (hp : p.Prime) (hq : q.Prime)
    (hlt : p < q) (op : Odd p) (oq : Odd q) (u : ℝ) :
    (cyclotomic (p*q) ℝ).eval (-exp u) *
      ((1+exp ((p:ℝ)*u))*(1+exp ((q:ℝ)*u))) =
      (1+exp u)*(1+exp ((↑p*↑q)*u)) := by
  let x := -(exp u)
  have geom (v : ℝ) : (cyclotomic p ℝ).eval v * (v-1) = v^p-1 := by
    letI : Fact p.Prime := ⟨hp⟩
    rw [cyclotomic_prime, eval_finset_sum]
    simp only [eval_pow, eval_X]
    exact geom_sum_mul _ _
  have hx : (cyclotomic (p*q) ℝ).eval x * (cyclotomic p ℝ).eval x =
      (cyclotomic p ℝ).eval (x^q) := by
    rw [← expand_eval, cyclotomic_expand_eq_cyclotomic_mul hq
      (Nat.not_dvd_of_pos_of_lt hp.pos hlt), eval_mul]
  have hstar : (cyclotomic (p*q) ℝ).eval x * ((x^p-1)*(x^q-1)) =
      (x-1)*(x^(p*q)-1) := by
    rw [← geom x, ← Nat.mul_comm q p, pow_mul, ← geom (x^q), ← hx]
    ring
  dsimp [x] at hstar
  rw [op.neg_pow, oq.neg_pow, (op.mul oq).neg_pow] at hstar
  rw [← Nat.cast_mul, exp_nat_mul, exp_nat_mul, exp_nat_mul]
  linear_combination hstar

private def top (p q u : ℝ) := (1+exp u)*(1+exp ((p*q)*u))
private def bot (p q u : ℝ) := (1+exp (p*u))*(1+exp (q*u))
private def topD (p q u : ℝ) := exp u*(1+exp ((p*q)*u)) + (1+exp u)*(p*q*exp ((p*q)*u))
private def botD (p q u : ℝ) := p*exp (p*u)*(1+exp (q*u)) + (1+exp (p*u))*(q*exp (q*u))

private theorem exp_linear (s u : ℝ) :
    HasDerivAt (fun v : ℝ => exp (s*v)) (s*exp (s*u)) u := by
  convert ((hasDerivAt_id u).const_mul s).exp using 1
  simp [mul_comm]

private theorem top_deriv (p q u : ℝ) : HasDerivAt (top p q) (topD p q u) u := by
  simpa [top,topD] using (((hasDerivAt_exp u).const_add 1).mul
    ((exp_linear (p*q) u).const_add 1))
private theorem bot_deriv (p q u : ℝ) : HasDerivAt (bot p q) (botD p q u) u := by
  simpa [bot,botD] using (((exp_linear p u).const_add 1).mul
    ((exp_linear q u).const_add 1))

theorem negative_numerator (p q u : ℝ) :
    spectrum (nw p q) (nd p q) u =
      topD p q u * bot p q u - top p q u * botD p q u := by
  simp [spectrum, Fin.sum_univ_succ, nd, nw, top, bot, topD, botD, add_mul, exp_add]
  ring

theorem negative_derivative_numerator {p q : ℕ} (hp : p.Prime) (hq : q.Prime)
    (hlt : p < q) (op : Odd p) (oq : Odd q) (u : ℝ) :
    spectrum (nw p q) (nd p q) u =
      (cyclotomic (p*q) ℝ).derivative.eval (-exp u) * (-exp u) * (bot p q u)^2 := by
  let P := cyclotomic (p*q) ℝ
  have h₁ := (((P.hasDerivAt (-exp u)).comp u (hasDerivAt_exp u).neg).mul (bot_deriv p q u))
  have heq : (fun v => (fun y => P.eval y) (-exp v) * bot p q v) = top p q :=
    funext (negative_cyclotomic_product hp hq hlt op oq)
  change HasDerivAt (fun v => P.eval (-exp v) * bot p q v) _ u at h₁
  rw [heq] at h₁
  have hd := h₁.unique (top_deriv p q u)
  change P.derivative.eval (-exp u) * (-exp u) * bot p q u +
    P.eval (-exp u) * botD p q u = topD p q u at hd
  rw [negative_numerator, ← hd, ← congrFun heq u]
  dsimp [P]
  ring

/-- There cannot be three distinct negative critical points of a binary cyclotomic polynomial. -/
theorem negative_critical_at_most_two {p q : ℕ} (hp : p.Prime) (hq : q.Prime)
    (hlt : p < q) (op : Odd p) (oq : Odd q) {a b c : ℝ}
    (hab : a < b) (hbc : b < c) (hc : c < 0)
    (hA : (cyclotomic (p*q) ℝ).derivative.eval a = 0)
    (hB : (cyclotomic (p*q) ℝ).derivative.eval b = 0)
    (hC : (cyclotomic (p*q) ℝ).derivative.eval c = 0) : False := by
  let g := spectrum (nw p q) (dn p q)
  have kill {x : ℝ} (hx : x < 0) (hX : (cyclotomic (p*q) ℝ).derivative.eval x = 0) :
      g (log (-x)) = 0 := by
    change spectrum (nw p q) (fun i => nd p q i - 1) (log (-x)) = 0
    rw [spectrum_shift, negative_derivative_numerator hp hq hlt op oq, exp_log (neg_pos.mpr hx),
      neg_neg, hX]
    ring
  have hcont : Continuous g := continuous_iff_continuousAt.mpr
    (fun x => (spectrum_hasDerivAt _ _ x).continuousAt)
  have h1 : log (-c) < log (-b) := log_lt_log (by linarith) (by linarith)
  have h2 : log (-b) < log (-a) := log_lt_log (by linarith) (by linarith)
  obtain ⟨s,hs,hs'⟩ := exists_deriv_eq_zero h1 hcont.continuousOn
    ((kill hc hC).trans (kill (by linarith) hB).symm)
  obtain ⟨t,ht,ht'⟩ := exists_deriv_eq_zero h2 hcont.continuousOn
    ((kill (by linarith) hB).trans (kill (by linarith) hA).symm)
  have hp3 : 3 ≤ p := by have := hp.two_le; obtain ⟨k,hk⟩ := op; omega
  exact (hs.2.trans ht.1).ne (spectrum_deriv_unique (by exact_mod_cast hp3)
    (by exact_mod_cast hlt) hs' ht')

theorem binary_endpoints {p q : ℕ} (hp : p.Prime) (hq : q.Prime)
    (hlt : p < q) (op : Odd p) (oq : Odd q) :
    let P := cyclotomic (p*q) ℝ
    P.eval (-1) = P.eval 0 ∧ P.derivative.eval (-1) < 0 ∧
      P.derivative.eval 0 = -1 ∧ 0 < P.derivative.eval 1 := by
  let P := cyclotomic (p*q) ℝ
  have hP : 1 < p*q := by nlinarith [hp.one_lt, hq.one_lt]
  have at0 (A : ℝ[X]) : A.eval 0 = A.coeff 0 := eval₂_at_zero (RingHom.id _)
  have hz : P.eval 0 = 1 := (at0 P).trans (cyclotomic_coeff_zero ℝ hP)
  have hn := negative_cyclotomic_product hp hq hlt op oq 0
  change P.eval _ * _ = _ at hn
  norm_num at hn
  have hN := negative_derivative_numerator hp hq hlt op oq 0
  rw [negative_numerator] at hN
  change _ = P.derivative.eval _ * _ * _ at hN
  norm_num [topD,botD,top,bot] at hN
  have hp' : (1:ℝ) < p := by exact_mod_cast hp.one_lt
  have hq' : (1:ℝ) < q := by exact_mod_cast hq.one_lt
  have hneg : P.derivative.eval (-1) < 0 := by
    nlinarith [mul_pos (sub_pos.mpr hp') (sub_pos.mpr hq')]
  have hnz : 0 < geo p 1 0 := geo_pos hp.pos 1 0
  have hs : 0 < geoSlope p 1 0 := by
    unfold geoSlope spectrum
    apply sum_pos'
    · intro i _
      positivity
    · exact ⟨⟨1,hp.one_lt⟩, mem_univ _, by norm_num⟩
  have scale : geoSlope p q 0 = q * geoSlope p 1 0 := by
    simp [geoSlope,spectrum,mul_sum]
  have geo0 : geo p (q:ℝ) 0 = geo p 1 0 := by simp [geo,spectrum]
  have hpos := positive_derivative_numerator hp hq hlt 0
  rw [positive_numerator, scale, geo0, exp_zero, mul_one] at hpos
  change _ = P.derivative.eval 1 * _ at hpos
  have posD : 0 < P.derivative.eval 1 := by
    apply lt_of_not_ge
    intro hle
    have hprod := mul_nonpos_of_nonpos_of_nonneg hle (sq_nonneg (geo p 1 0))
    nlinarith [mul_pos (mul_pos (sub_pos.mpr hq') hs) hnz]
  have heq := congrArg (fun Q : ℝ[X] => Q.coeff 1)
    (cyclotomic_expand_eq_cyclotomic_mul hq (Nat.not_dvd_of_pos_of_lt hp.pos hlt) ℝ)
  have hcp : (cyclotomic p ℝ).coeff 1 = 1 := by
    letI : Fact p.Prime := ⟨hp⟩
    simp [cyclotomic_prime,finset_sum_coeff,coeff_X_pow, Finset.mem_range.mpr hp.one_lt]
  have he : ((expand ℝ q) (cyclotomic p ℝ)).coeff 1 = 0 := by
    rw [coeff_expand hq.pos]
    simp [Nat.not_dvd_of_pos_of_lt Nat.zero_lt_one hq.one_lt, hq.ne_zero]
  change ((expand ℝ q) (cyclotomic p ℝ)).coeff 1 = (P * cyclotomic p ℝ).coeff 1 at heq
  rw [he,coeff_mul,Finset.Nat.sum_antidiagonal_eq_sum_range_succ (fun i j => P.coeff i * (cyclotomic p ℝ).coeff j)] at heq
  have hc0 : P.coeff 0 = 1 := cyclotomic_coeff_zero ℝ hP
  norm_num [Finset.sum_range_succ, hcp, hc0, cyclotomic_coeff_zero ℝ hp.one_lt] at heq
  exact ⟨by change P.eval (-1) = _; linarith, hneg, by
    change P.derivative.eval 0 = -1
    rw [at0,coeff_derivative]
    norm_num
    linarith, posD⟩

private theorem interior_positive {P : ℝ[X]} (he : P.eval (-1) = P.eval 0)
    (hd : P.derivative.eval (-1) < 0) :
    ∃ c ∈ Set.Ioo (-1:ℝ) 0, 0 < P.derivative.eval c := by
  by_contra! hn
  let D := Set.Icc (-1:ℝ) 0
  have ha : (-1:ℝ) ∈ D := by constructor <;> norm_num
  have hb : (0:ℝ) ∈ D := by constructor <;> norm_num
  have am : AntitoneOn (fun x => P.eval x) D :=
    antitoneOn_of_deriv_nonpos (convex_Icc ..) P.continuous.continuousOn
      (fun x _ => (P.hasDerivAt x).differentiableAt.differentiableWithinAt)
      (fun x hx => by rw [(P.hasDerivAt x).deriv]; exact hn x (by simpa [D, interior_Icc] using hx))
  have flat (x : ℝ) (hx : x ∈ D) : P.eval x = P.eval (-1) := by
    have l := am ha hx hx.1
    have r := am hx hb hx.2
    linarith
  have hconst := ((hasDerivAt_const (-1:ℝ) (P.eval (-1))).hasDerivWithinAt (s := D)).congr flat rfl
  have hu := uniqueDiffOn_Icc (show (-1:ℝ)<0 by norm_num) (-1) ha
  have hsame := ((P.hasDerivAt (-1)).hasDerivWithinAt.derivWithin hu).symm.trans (hconst.derivWithin hu)
  linarith

/-- The three binary critical points exist inside the strict signed unit intervals. -/
theorem binary_three_exist {p q : ℕ} (hp : p.Prime) (hq : q.Prime)
    (hlt : p < q) (op : Odd p) (oq : Odd q) :
    let D := (cyclotomic (p*q) ℝ).derivative
    ∃ a b c : ℝ, -1 < a ∧ a < b ∧ b < 0 ∧ 0 < c ∧ c < 1 ∧
      D.eval a = 0 ∧ D.eval b = 0 ∧ D.eval c = 0 := by
  let P := cyclotomic (p*q) ℝ
  obtain ⟨he,hN,hZ,hP⟩ := binary_endpoints hp hq hlt op oq
  obtain ⟨x,hx,hx'⟩ := interior_positive he hN
  obtain ⟨a,ha,ha'⟩ := intermediate_value_Ioo hx.1.le P.derivative.continuous.continuousOn
    (show (0:ℝ) ∈ Set.Ioo (P.derivative.eval (-1)) (P.derivative.eval x) from ⟨hN,hx'⟩)
  obtain ⟨b,hb,hb'⟩ := intermediate_value_Ioo' hx.2.le P.derivative.continuous.continuousOn
    (show (0:ℝ) ∈ Set.Ioo (P.derivative.eval 0) (P.derivative.eval x) from ⟨by rw [hZ]; norm_num,hx'⟩)
  obtain ⟨c,hc,hc'⟩ := intermediate_value_Ioo (show (0:ℝ) ≤ 1 by norm_num)
    P.derivative.continuous.continuousOn
    (show (0:ℝ) ∈ Set.Ioo (P.derivative.eval 0) (P.derivative.eval 1) from ⟨by rw [hZ]; norm_num,hP⟩)
  exact ⟨a,b,c,ha.1,ha.2.trans hb.1,hb.2,hc.1,hc.2,ha',hb',hc'⟩

private theorem zero_product_slope (D : ℝ[X]) {x m : ℝ → ℝ} {u v : ℝ}
    (hx : HasDerivAt x v u) (hm : DifferentiableAt ℝ m u)
    (hz : D.eval (x u) = 0) (hd : D.derivative.eval (x u) = 0) :
    deriv (fun t => D.eval (x t) * m t) u = 0 := by
  have h := (((D.hasDerivAt (x u)).comp u hx).mul hm.hasDerivAt).deriv
  simpa [Function.comp_def, hz, hd] using h

theorem positive_critical_simple {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hlt : p < q)
    {a : ℝ} (ha : 0 < a) (hA : (cyclotomic (p*q) ℝ).derivative.eval a = 0) :
    (cyclotomic (p*q) ℝ).derivative.derivative.eval a ≠ 0 := by
  intro hd
  let D := (cyclotomic (p*q) ℝ).derivative
  let m := fun t => exp t * (geo p 1 t)^2 * exp (-(p:ℝ)*t)
  have hrep : spectrum (pw q : Fin p × Fin p → ℝ) (fun i => pd q i - p) =
      (fun t => D.eval (exp t) * m t) := by
    funext t
    rw [spectrum_shift, positive_derivative_numerator hp hq hlt]
    dsimp [D,m]
    ring
  have h := positive_spectrum_slope hp.one_lt hlt (log a)
  rw [hrep] at h
  have hdiff : DifferentiableAt ℝ m (log a) :=
    (((hasDerivAt_exp _).differentiableAt.mul ((geo_deriv p 1 _).differentiableAt.pow 2)).mul
      (exp_linear (-(p:ℝ)) _).differentiableAt)
  have hz := zero_product_slope D (hasDerivAt_exp (log a)) hdiff
    (by simpa [D, exp_log ha] using hA) (by simpa [D, exp_log ha] using hd)
  linarith

theorem negative_pair_simple {p q : ℕ} (hp : p.Prime) (hq : q.Prime)
    (hlt : p < q) (op : Odd p) (oq : Odd q) {a b : ℝ} (hab : a < b) (hb : b < 0)
    (hA : (cyclotomic (p*q) ℝ).derivative.eval a = 0)
    (hB : (cyclotomic (p*q) ℝ).derivative.eval b = 0) :
    (cyclotomic (p*q) ℝ).derivative.derivative.eval a ≠ 0 ∧
    (cyclotomic (p*q) ℝ).derivative.derivative.eval b ≠ 0 := by
  let D := (cyclotomic (p*q) ℝ).derivative
  let g := spectrum (nw (p:ℝ) q) (dn p q)
  let m := fun t => -exp t * (bot p q t)^2 * exp (-1*t)
  have heq : g = (fun t => D.eval (-exp t) * m t) := by
    funext t
    change spectrum (nw p q) (fun i => nd p q i-1) t = _
    rw [spectrum_shift, negative_derivative_numerator hp hq hlt op oq]
    dsimp [D,m]
    ring
  have kill {x : ℝ} (hx : x < 0) (hX : D.eval x = 0) : g (log (-x)) = 0 := by
    rw [heq]
    simp only [exp_log (neg_pos.mpr hx), neg_neg, hX, zero_mul]
  have dkill {x : ℝ} (hx : x < 0) (hX : D.eval x = 0) (hd : D.derivative.eval x = 0) :
      deriv g (log (-x)) = 0 := by
    rw [heq]
    have hm : DifferentiableAt ℝ m (log (-x)) :=
      (((hasDerivAt_exp _).neg.differentiableAt.mul ((bot_deriv p q _).differentiableAt.pow 2)).mul
        (exp_linear (-1) _).differentiableAt)
    exact zero_product_slope D (hasDerivAt_exp _).neg hm
      (by simpa only [Pi.neg_apply, exp_log (neg_pos.mpr hx), neg_neg] using hX)
      (by simpa only [Pi.neg_apply, exp_log (neg_pos.mpr hx), neg_neg] using hd)
  have hL : log (-b) < log (-a) := log_lt_log (by linarith) (by linarith)
  have hcont : Continuous g := continuous_iff_continuousAt.mpr
    (fun x => (spectrum_hasDerivAt _ _ x).continuousAt)
  obtain ⟨t,ht,ht'⟩ := exists_deriv_eq_zero hL hcont.continuousOn
    ((kill hb hB).trans (kill (by linarith) hA).symm)
  have hp3 : 3 ≤ p := by have := hp.two_le; obtain ⟨k,hk⟩ := op; omega
  have H := @spectrum_deriv_unique p q (by exact_mod_cast hp3) (by exact_mod_cast hlt)
  exact ⟨fun ha' => ht.2.ne (H ht' (dkill (by linarith) hA ha')),
    fun hb' => ht.1.ne (H (dkill hb hB hb') ht')⟩

/-- The complete binary theorem. The biconditional enumerates all real roots;
the last assertion verifies simplicity at each one. -/
theorem binary_exact {p q : ℕ} (hp : p.Prime) (hq : q.Prime) (hlt : p < q)
    (op : Odd p) (oq : Odd q) :
    let D := (cyclotomic (p*q) ℝ).derivative
    ∃ a b c : ℝ, -1 < a ∧ a < b ∧ b < 0 ∧ 0 < c ∧ c < 1 ∧
      (∀ x, D.eval x = 0 ↔ x = a ∨ x = b ∨ x = c) ∧
      (∀ x, D.eval x = 0 → D.derivative.eval x ≠ 0) := by
  let D := (cyclotomic (p*q) ℝ).derivative
  obtain ⟨a,b,c,ha,hab,hb,hc,hc',hA,hB,hC⟩ := binary_three_exist hp hq hlt op oq
  have allroots (x : ℝ) (hx : D.eval x = 0) : x = a ∨ x = b ∨ x = c := by
    obtain h | h | h := lt_trichotomy x 0
    · by_cases e : x = a
      · exact Or.inl e
      by_cases e' : x = b
      · exact Or.inr (Or.inl e')
      exfalso
      rcases lt_or_gt_of_ne e with hxa | hax
      · exact negative_critical_at_most_two hp hq hlt op oq hxa hab hb hx hA hB
      rcases lt_or_gt_of_ne e' with hxb | hbx
      · exact negative_critical_at_most_two hp hq hlt op oq hax hxb hb hA hx hB
      · exact negative_critical_at_most_two hp hq hlt op oq hab hbx h hA hB hx
    · have hz := (binary_endpoints hp hq hlt op oq).2.2.1
      subst x
      change D.eval 0 = -1 at hz
      linarith
    · exact Or.inr (Or.inr (positive_critical_unique hp hq hlt h hc hx hC))
  refine ⟨a,b,c,ha,hab,hb,hc,hc',fun x => ⟨allroots x, ?_⟩, ?_⟩
  · rintro (rfl | rfl | rfl) <;> assumption
  · intro x hx
    have hn := negative_pair_simple hp hq hlt op oq hab hb hA hB
    rcases allroots x hx with rfl | rfl | rfl
    · exact hn.1
    · exact hn.2
    · exact positive_critical_simple hp hq hlt hc hC

theorem cyclotomic_fifteen_formula :
    cyclotomic 15 ℝ = X^8 - X^7 + X^5 - X^4 + X^3 - X + 1 := by
  have h := cyclotomic_expand_eq_cyclotomic_mul (n := 3) (p := 5) (by decide) (by decide) ℝ
  have hp : cyclotomic 3 ℝ = (1+X+X^2) := by
    letI : Fact (Nat.Prime 3) := ⟨by decide⟩
    rw [cyclotomic_prime]
    norm_num [sum_range_succ]
  apply mul_right_cancel₀ ((cyclotomic.monic 3 ℝ).ne_zero)
  change cyclotomic (3*5) ℝ * _ = _
  rw [← h, hp]
  simp [expand_X]
  ring

/-- Certified dyadic brackets for all three roots in the n = 15 explorer example. -/
theorem fifteen_dyadic_brackets :
    let D := (cyclotomic 15 ℝ).derivative
    (∃ x ∈ Set.Ioo ((-925:ℝ)/1024) (-924/1024), D.eval x = 0) ∧
    (∃ x ∈ Set.Ioo ((-445:ℝ)/1024) (-444/1024), D.eval x = 0) ∧
    (∃ x ∈ Set.Ioo ((685:ℝ)/1024) (686/1024), D.eval x = 0) := by
  let D := (cyclotomic 15 ℝ).derivative
  change (∃ x ∈ _, D.eval x = 0) ∧ (∃ x ∈ _, D.eval x = 0) ∧ (∃ x ∈ _, D.eval x = 0)
  refine ⟨intermediate_value_Ioo (by norm_num) D.continuous.continuousOn ?_,
    intermediate_value_Ioo' (by norm_num) D.continuous.continuousOn ?_,
    intermediate_value_Ioo (by norm_num) D.continuous.continuousOn ?_⟩ <;>
    constructor <;> norm_num [D,cyclotomic_fifteen_formula, derivative_pow]

end
end Cyclo.Binary
