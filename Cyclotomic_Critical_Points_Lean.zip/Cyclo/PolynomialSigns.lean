import Mathlib

/-! A polynomial test changes sign at precisely the preimages of the odd-multiplicity
roots.  Orthogonality of a pulled-back signal therefore bounds their number. -/
noncomputable section
open Polynomial Set MeasureTheory
open scoped BigOperators Polynomial
namespace Cyclo
open Classical

/-- Distinct roots in the observation interval, with odd multiplicity. -/
def oddRootsIn (D : ℝ[X]) (s : Set ℝ) : Finset ℝ := by
  classical
  exact D.roots.toFinset.filter (fun r => r ∈ s ∧ Odd (D.rootMultiplicity r))

private theorem noZero_sameSign {g : ℝ → ℝ} (hc : Continuous g) (hn : ∀ x, g x ≠ 0)
    (u v : ℝ) : 0 ≤ g u * g v := by
  by_contra! h
  rcases (mul_neg_iff.mp h) with ⟨hu,hv⟩ | ⟨hu,hv⟩
  · obtain ⟨x,hx⟩ := intermediate_value_univ v u hc (show 0 ∈ Icc (g v) (g u) from ⟨hv.le,hu.le⟩)
    exact hn x hx
  · obtain ⟨x,hx⟩ := intermediate_value_univ u v hc (show 0 ∈ Icc (g u) (g v) from ⟨hu.le,hv.le⟩)
    exact hn x hx

private theorem signedFactor {c : ℝ → ℝ} (hc : Continuous c)
    (hm : StrictMono c ∨ StrictAnti c) (r : ℝ) (n : ℕ) (u v : ℝ) :
    0 ≤ (((if r ∈ range c ∧ Odd n then u - Function.invFun c r else 1) *
      (c u-r)^n) * ((if r ∈ range c ∧ Odd n then v-Function.invFun c r else 1) *
      (c v-r)^n)) := by
  classical
  by_cases hr : r ∈ range c
  · obtain ⟨t, rfl⟩ := hr
    have hi : Function.Injective c := hm.elim StrictMono.injective StrictAnti.injective
    have ht := Function.leftInverse_invFun hi t
    by_cases ho : Odd n
    · simp only [mem_range_self, ho, and_self, if_true, ht]
      have hn {a b : ℝ} (hab : 0 ≤ a*b) : 0 ≤ a*b^n := by
        rcases ho with ⟨k,hk⟩
        rw [hk, pow_succ, pow_mul]
        nlinarith only [mul_nonneg hab (pow_nonneg (sq_nonneg b) k)]
      rcases hm with inc | dec
      · apply mul_nonneg <;> apply hn
        · rcases le_total u t with h|h
          · exact mul_nonneg_of_nonpos_of_nonpos (sub_nonpos.mpr h) (sub_nonpos.mpr (inc.monotone h))
          · exact mul_nonneg (sub_nonneg.mpr h) (sub_nonneg.mpr (inc.monotone h))
        · rcases le_total v t with h|h
          · exact mul_nonneg_of_nonpos_of_nonpos (sub_nonpos.mpr h) (sub_nonpos.mpr (inc.monotone h))
          · exact mul_nonneg (sub_nonneg.mpr h) (sub_nonneg.mpr (inc.monotone h))
      · have hneg (x : ℝ) : (x-t)*(c x - c t)^n ≤ 0 := by
          have h : 0 ≤ (t-x)*(c x-c t) := by
            rcases le_total x t with h|h
            · exact mul_nonneg (sub_nonneg.mpr h) (sub_nonneg.mpr (dec.antitone h))
            · exact mul_nonneg_of_nonpos_of_nonpos (sub_nonpos.mpr h) (sub_nonpos.mpr (dec.antitone h))
          linarith only [hn h]
        exact mul_nonneg_of_nonpos_of_nonpos (hneg u) (hneg v)
    · simp only [ho, and_false, if_false, one_mul]
      exact mul_nonneg ((Nat.not_odd_iff_even.mp ho).pow_nonneg _) ((Nat.not_odd_iff_even.mp ho).pow_nonneg _)
  · simp only [hr, false_and, if_false, one_mul, ← mul_pow]
    exact pow_nonneg (noZero_sameSign (hc.sub continuous_const)
      (fun x h => hr ⟨x, sub_eq_zero.mp h⟩) u v) _

private theorem test_gives_sameSign (D : ℝ[X]) (hD : D ≠ 0)
    (c : ℝ → ℝ) (hc : Continuous c) (hm : StrictMono c ∨ StrictAnti c) (u v : ℝ) :
    let P : ℝ[X] := ∏ r ∈ oddRootsIn D (range c), (X-C (Function.invFun c r))
    0 ≤ (P.eval u * D.eval (c u)) * (P.eval v * D.eval (c v)) := by
  classical
  obtain ⟨q, hq, _, hqr⟩ := D.exists_prod_multiset_X_sub_C_mul
  have hqn : q ≠ 0 := by intro hz; simp [hz] at hq; exact hD hq.symm
  have hqe : ∀ x, q.eval x ≠ 0 := by
    intro x hx
    have hx' : x ∈ q.roots := (mem_roots hqn).2 hx
    simp [hqr] at hx'
  have he (x : ℝ) : D.eval (c x) =
      (∏ r ∈ D.roots.toFinset, (c x-r)^D.rootMultiplicity r) * q.eval (c x) := by
    have hh := congrArg (Polynomial.eval (c x)) hq
    simpa [Finset.prod_multiset_map_count, eval_prod, count_roots] using hh.symm
  let L (x r : ℝ) : ℝ := if r ∈ range c ∧ Odd (D.rootMultiplicity r) then x-Function.invFun c r else 1
  have hp (x : ℝ) : (∏ r ∈ oddRootsIn D (range c), (X-C (Function.invFun c r) : ℝ[X])).eval x =
      ∏ r ∈ D.roots.toFinset, L x r := by
    rw [eval_prod]
    simp only [oddRootsIn, Finset.prod_filter, eval_sub, eval_X, eval_C, L]
  dsimp only
  rw [hp, hp, he, he]
  let B (x r : ℝ) := L x r * (c x-r)^D.rootMultiplicity r
  have hfactor (x : ℝ) :
      (∏ r ∈ D.roots.toFinset, L x r) * ((∏ r ∈ D.roots.toFinset, (c x-r)^D.rootMultiplicity r) * q.eval (c x))
      = (∏ r ∈ D.roots.toFinset, B x r) * q.eval (c x) := by
    rw [← mul_assoc, ← Finset.prod_mul_distrib]
  rw [hfactor,hfactor, mul_mul_mul_comm, ← Finset.prod_mul_distrib]
  exact mul_nonneg (Finset.prod_nonneg fun r _ => signedFactor hc hm r (D.rootMultiplicity r) u v)
    (noZero_sameSign q.continuous hqe (c u) (c v))

/-- Under polynomial moment cancellation, the derivative polynomial has at least
`m` distinct odd-multiplicity roots in the range of a monotone coordinate. -/
theorem oddRootsIn_card_of_orthogonal (D : ℝ[X]) (hD : D ≠ 0) (c w : ℝ → ℝ)
    (hc : Continuous c) (hm : StrictMono c ∨ StrictAnti c)
    (hw : Continuous w) (hwn : ∀ x, w x ≠ 0) (m : ℕ)
    (hmom : ∀ P : ℝ[X], P.natDegree < m →
      Integrable (fun x => P.eval x * (w x * D.eval (c x))) ∧
      (∫ x, P.eval x * (w x * D.eval (c x))) = 0) :
    m ≤ (oddRootsIn D (range c)).card := by
  classical
  by_contra! h
  let R := oddRootsIn D (range c)
  let P : ℝ[X] := ∏ r ∈ R, (X - C (Function.invFun c r))
  have hP : P ≠ 0 := Finset.prod_ne_zero_iff.mpr fun r _ => X_sub_C_ne_zero _
  have hdeg : P.natDegree ≤ R.card := by
    simp [P]
  let g (x : ℝ) := P.eval x * (w x * D.eval (c x))
  have hg : Continuous g := P.continuous.mul (hw.mul (D.continuous.comp hc))
  have hsame (u v : ℝ) : 0 ≤ g u * g v := by
    have H := mul_nonneg (test_gives_sameSign D hD c hc hm u v) (noZero_sameSign hw hwn u v)
    dsimp only [g]
    convert H using 1
    ring
  obtain ⟨hint,hzero⟩ := hmom P (lt_of_le_of_lt hdeg h)
  have hi : Function.Injective c := hm.elim StrictMono.injective StrictAnti.injective
  have hf := (finite_setOf_isRoot hP).union ((finite_setOf_isRoot hD).preimage hi.injOn)
  obtain ⟨z,hz⟩ := hf.infinite_compl.nonempty
  have hzP : P.eval z ≠ 0 := fun e => hz (Or.inl e)
  have hzD : D.eval (c z) ≠ 0 := fun e => hz (Or.inr e)
  have hn : g z ≠ 0 := mul_ne_zero hzP (mul_ne_zero (hwn z) hzD)
  have hI : (∫ x, g z * g x) = 0 := by rw [integral_const_mul]; change g z * (∫ x, P.eval x * (w x * D.eval (c x))) = 0; rw [hzero,mul_zero]
  have H := (integral_eq_zero_iff_of_nonneg (f := fun x => g z * g x) (hsame z) (hint.const_mul (g z))).mp hI
  have heq := ((continuous_const.mul hg).ae_eq_iff_eq volume continuous_zero).mp H
  exact mul_self_ne_zero.mpr hn (congrFun heq z)

end Cyclo
