import Cyclo.Identity
import Cyclo.CertificateBrackets

/-! Exact dyadic sign brackets and distinct critical points for the Heaney example. -/
namespace Cyclo.Examples
open Polynomial Set
open Cert
noncomputable section
theorem three_exact (x : ℝ) :
    (cyclotomic 3 ℝ).derivative.eval x = 0 ↔ x = -(1/2) := by
  rw [Polynomial.cyclotomic_three]
  simp [derivative_add, derivative_pow]
  constructor <;> intro h <;> linarith


theorem bracket_root (D : ℝ[X]) (h : ℤ)
    (hs : D.eval ((h:ℝ)/1024) * D.eval (((h:ℝ)+1)/1024) < 0) :
    ∃ x : ℝ, (h:ℝ)/1024 < x ∧ x < ((h:ℝ)+1)/1024 ∧ D.eval x = 0 := by
  have hab : (h:ℝ)/1024 ≤ ((h:ℝ)+1)/1024 := by linarith
  have hv : (0 : ℝ) ∈ D.eval '' Ioo ((h:ℝ)/1024) (((h:ℝ)+1)/1024) := by
    rcases mul_neg_iff.mp hs with ⟨hp,hn⟩ | ⟨hn,hp⟩
    · exact intermediate_value_Ioo' hab D.continuous.continuousOn ⟨hn,hp⟩
    · exact intermediate_value_Ioo hab D.continuous.continuousOn ⟨hn,hp⟩
  obtain ⟨x,hx,hz⟩ := hv
  exact ⟨x,hx.1,hx.2,hz⟩

def brackets885 := brackets_885_neg ++ brackets_885_pos
def brackets1239 := brackets_1239_neg ++ brackets_1239_pos

theorem critical885_in_each_bracket (h : ℤ) (hm : h ∈ brackets885) :
    ∃ x : ℝ, (h:ℝ)/1024 < x ∧ x < ((h:ℝ)+1)/1024 ∧ (cyclotomic 885 ℝ).derivative.eval x = 0 := by
  apply bracket_root
  exact (List.mem_append.mp hm).elim (signs_885_neg h) (signs_885_pos h)

theorem critical1239_in_each_bracket (h : ℤ) (hm : h ∈ brackets1239) :
    ∃ x : ℝ, (h:ℝ)/1024 < x ∧ x < ((h:ℝ)+1)/1024 ∧ (cyclotomic 1239 ℝ).derivative.eval x = 0 := by
  apply bracket_root
  exact (List.mem_append.mp hm).elim (signs_1239_neg h) (signs_1239_pos h)

/-- Number of distinct derivative zeros in an open real interval. -/
def signedRootCount (n : ℕ) (a b : ℝ) : ℕ := by
  classical
  exact ((cyclotomic n ℝ).derivative.roots.toFinset.filter (· ∈ Ioo a b)).card

theorem bracket_count {n : ℕ} (hn : 0 < n) (S : Finset ℤ) (a b : ℤ)
    (hbounds : ∀ h ∈ S, a ≤ h ∧ h+1 ≤ b)
    (hroots : ∀ h ∈ S, ∃ x : ℝ, (h:ℝ)/1024 < x ∧ x < ((h:ℝ)+1)/1024 ∧
      (cyclotomic n ℝ).derivative.eval x = 0) :
    S.card ≤ signedRootCount n ((a:ℝ)/1024) ((b:ℝ)/1024) := by
  classical
  let w (h : ℤ) : ℝ := if hh : h ∈ S then (hroots h hh).choose else 0
  have hw (h : ℤ) (hm : h ∈ S) : (h:ℝ)/1024 < w h ∧ w h < ((h:ℝ)+1)/1024 ∧
      (cyclotomic n ℝ).derivative.eval (w h) = 0 := by
    simpa only [w,dif_pos hm] using (hroots h hm).choose_spec
  apply Finset.card_le_card_of_injOn w
  · intro h hm
    obtain ⟨hx,hy,hz⟩ := hw h hm
    obtain ⟨ha,hb⟩ := hbounds h hm
    have ha' : (a:ℝ) ≤ h := by exact_mod_cast ha
    have hb' : (h:ℝ)+1 ≤ b := by exact_mod_cast hb
    exact Finset.mem_filter.mpr ⟨Multiset.mem_toFinset.mpr
      ((Polynomial.mem_roots (cyclo_derivative_ne_zero hn)).mpr hz),
      ⟨by linarith,by linarith⟩⟩
  · intro i hi j hj he
    have hlt (i j : ℤ) (hi : i ∈ S) (hj : j ∈ S) (hij : i < j) : w i < w j := by
      have sep : i+1 ≤ j := by omega
      have sep' : (i:ℝ)+1 ≤ j := by exact_mod_cast sep
      linarith [(hw i hi).2.1,(hw j hj).1]
    exact le_antisymm (le_of_not_gt (fun hg => (hlt j i hj hi hg).ne he.symm))
      (le_of_not_gt (fun hg => (hlt i j hi hj hg).ne he))

theorem critical885_lower_counts :
    5 ≤ signedRootCount 885 (-1) 0 ∧ 2 ≤ signedRootCount 885 0 1 := by
  constructor
  · let s : Finset ℤ := {-1023,-1009,-957,-934,-445}
    have hl := bracket_count (n := 885) (by decide) s (-1024) 0 (by decide)
      (fun h hm => critical885_in_each_bracket h
        ((by decide : ∀ i ∈ s, i ∈ brackets885) h hm))
    have hcard : s.card = 5 := by decide
    norm_num [hcard] at hl ⊢
    exact hl
  · let s : Finset ℤ := {685,1017}
    have hl := bracket_count (n := 885) (by decide) s 0 1024 (by decide)
      (fun h hm => critical885_in_each_bracket h
        ((by decide : ∀ i ∈ s, i ∈ brackets885) h hm))
    have hcard : s.card = 2 := by decide
    norm_num [hcard] at hl ⊢
    exact hl

theorem critical1239_lower_counts :
    3 ≤ signedRootCount 1239 (-1) 0 ∧ 2 ≤ signedRootCount 1239 0 1 := by
  constructor
  · let s : Finset ℤ := {-1023,-1009,-483}
    have hl := bracket_count (n := 1239) (by decide) s (-1024) 0 (by decide)
      (fun h hm => critical1239_in_each_bracket h
        ((by decide : ∀ i ∈ s, i ∈ brackets1239) h hm))
    have hcard : s.card = 3 := by decide
    norm_num [hcard] at hl ⊢
    exact hl
  · let s : Finset ℤ := {740,1018}
    have hl := bracket_count (n := 1239) (by decide) s 0 1024 (by decide)
      (fun h hm => critical1239_in_each_bracket h
        ((by decide : ∀ i ∈ s, i ∈ brackets1239) h hm))
    have hcard : s.card = 2 := by decide
    norm_num [hcard] at hl ⊢
    exact hl

end
end Cyclo.Examples
