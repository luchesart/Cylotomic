import Cyclo.Examples
import Cyclo.Exterior
import Cyclo.RolleBounds
import Cyclo.CertificateBounds

/-! The signed endpoint witnesses, the coefficient variation bounds, and the exclusion of
the centre and exterior together give the total counts with multiplicity. -/
namespace Cyclo
open Polynomial Set
open Examples

private theorem prime_step_nonzero_at_zero {n p : ℕ} (hn : 0 < n) (hp : p.Prime)
    (hd : ¬p ∣ n) (hnz : (cyclotomic n ℝ).derivative.eval 0 ≠ 0) :
    (cyclotomic (n*p) ℝ).derivative.eval 0 ≠ 0 := by
  have hh := congrArg (fun q : ℝ[X] => q.derivative.eval 0)
    (cyclotomic_expand_eq_cyclotomic_mul hp hd ℝ)
  have ht : p-1 ≠ 0 := by have := hp.two_le; omega
  simp only [derivative_expand, derivative_mul, eval_add, eval_mul, eval_X, eval_pow,
    zero_pow ht, mul_zero] at hh
  have hv := cyclo_eval_ne_zero (Nat.mul_pos hn hp.pos) (x:=0) (by norm_num)
  intro he
  rw [he, zero_mul, zero_add] at hh
  exact (mul_ne_zero hv hnz) hh.symm

/-- A squarefree product of primes does not have a critical point at zero. -/
theorem sqfree_derivative_zero_ne (ps : List ℕ) (hnd : ps.Nodup)
    (hpr : ∀ p ∈ ps, p.Prime) : (cyclotomic ps.prod ℝ).derivative.eval 0 ≠ 0 := by
  induction ps with
  | nil => simp
  | cons p ps ih =>
    have hp := hpr p (by simp)
    have hpr' : ∀ q ∈ ps, Nat.Prime q := fun q h => hpr q (by simp [h])
    rcases List.nodup_cons.mp hnd with ⟨hnot, hnd'⟩
    rw [List.prod_cons, Nat.mul_comm p]
    exact prime_step_nonzero_at_zero (prime_list_prod_pos ps hpr') hp
      (prime_not_dvd_prod hp ps hpr' hnot) (ih hnd' hpr')

/-- Real roots counted by signed intervals, then counted with their multiplicities. -/
theorem certified_count_of_caps {n l r : ℕ} (hn : 2 < n)
    (hnz : (cyclotomic n ℝ).derivative.eval 0 ≠ 0)
    (low : l ≤ signedRootCount n (-1) 0 ∧ r ≤ signedRootCount n 0 1)
    (upper : RootCap (Ioo (-1) 0) (cyclotomic n ℝ).derivative.eval l ∧
      RootCap (Ioo 0 1) (cyclotomic n ℝ).derivative.eval r)
    (simple : ∀ x, x ∈ Ioo (-1) 0 ∪ Ioo 0 1 → (cyclotomic n ℝ).derivative.eval x = 0 →
      (cyclotomic n ℝ).derivative.rootMultiplicity x = 1) :
    signedRootCount n (-1) 0 = l ∧ signedRootCount n 0 1 = r ∧
      (cyclotomic n ℝ).derivative.roots.card = l+r ∧
      ∀ x, (cyclotomic n ℝ).derivative.eval x = 0 →
        (cyclotomic n ℝ).derivative.rootMultiplicity x = 1 := by
  classical
  let D := (cyclotomic n ℝ).derivative
  let Z := D.roots.toFinset
  let A := Z.filter (· ∈ Ioo (-1:ℝ) 0)
  let B := Z.filter (· ∈ Ioo (0:ℝ) 1)
  have hm {x : ℝ} (hx : x ∈ Z) : D.eval x = 0 :=
    Polynomial.isRoot_of_mem_roots (Multiset.mem_toFinset.mp hx)
  have hloc {x : ℝ} (hx : D.eval x = 0) : x ∈ Ioo (-1:ℝ) 0 ∪ Ioo 0 1 := by
    have h := cyclotomic_critical_mem_Ioo hn hx
    have hxne : x ≠ 0 := by rintro rfl; exact hnz hx
    rcases lt_or_gt_of_ne hxne with hm | hp
    · exact Or.inl ⟨h.1,hm⟩
    · exact Or.inr ⟨hp,h.2⟩
  have hs {x : ℝ} (hx : D.eval x = 0) : D.rootMultiplicity x = 1 := simple x (hloc hx) hx
  have hl : A.card = l := le_antisymm (upper.1 A (fun _ hx =>
    ⟨(Finset.mem_filter.mp hx).2, hm (Finset.mem_filter.mp hx).1⟩)) low.1
  have hr : B.card = r := le_antisymm (upper.2 B (fun _ hx =>
    ⟨(Finset.mem_filter.mp hx).2, hm (Finset.mem_filter.mp hx).1⟩)) low.2
  have hu : A ∪ B = Z := by
    ext x
    constructor
    · intro h
      rcases Finset.mem_union.mp h with h | h <;> exact (Finset.mem_filter.mp h).1
    · intro hx
      rcases hloc (hm hx) with h | h
      · exact Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨hx,h⟩)
      · exact Finset.mem_union_right _ (Finset.mem_filter.mpr ⟨hx,h⟩)
  have hd : Disjoint A B := by
    apply Finset.disjoint_left.mpr
    intro x ha hb
    exact lt_asymm (Finset.mem_filter.mp ha).2.2 (Finset.mem_filter.mp hb).2.1
  have hdup : D.roots.Nodup := by
    apply Multiset.nodup_iff_count_le_one.mpr
    intro x
    by_cases hx : x ∈ D.roots
    · rw [Polynomial.count_roots, hs (Polynomial.isRoot_of_mem_roots hx)]
    · simp [hx]
  have hc : D.roots.card = l+r := by
    rw [← Multiset.toFinset_card_of_nodup hdup]
    change Z.card = l+r
    rw [← hu, Finset.card_union_of_disjoint hd, hl, hr]
  exact ⟨hl,hr,hc,fun _ hx => hs hx⟩


/-- Five negative and two positive simple critical points of Φ₈₈₅. -/
theorem critical885_exact :
    signedRootCount 885 (-1) 0 = 5 ∧ signedRootCount 885 0 1 = 2 ∧
      (cyclotomic 885 ℝ).derivative.roots.card = 7 ∧
      ∀ x, (cyclotomic 885 ℝ).derivative.eval x = 0 →
        (cyclotomic 885 ℝ).derivative.rootMultiplicity x = 1 :=
  certified_count_of_caps (by decide) (sqfree_derivative_zero_ne [59,5,3] (by decide) (by decide))
    critical885_lower_counts case885_upper case885_simple

/-- Three negative and two positive simple critical points of Φ₁₂₃₉. -/
theorem critical1239_exact :
    signedRootCount 1239 (-1) 0 = 3 ∧ signedRootCount 1239 0 1 = 2 ∧
      (cyclotomic 1239 ℝ).derivative.roots.card = 5 ∧
      ∀ x, (cyclotomic 1239 ℝ).derivative.eval x = 0 →
        (cyclotomic 1239 ℝ).derivative.rootMultiplicity x = 1 :=
  certified_count_of_caps (by decide) (sqfree_derivative_zero_ne [59,7,3] (by decide) (by decide))
    critical1239_lower_counts case1239_upper case1239_simple

/-- Hong--Sommese's universal prime-replacement monotonicity fails for the prime pair
5 < 7 and the base 177, with all three side conditions checked. -/
theorem heaney_monotonicity_failure :
    ¬ (∀ n p q : ℕ, Odd n → Squarefree n → Odd p → Odd q → Nat.Prime p → Nat.Prime q → p < q → ¬p ∣ n → ¬q ∣ n →
      (cyclotomic (n*p) ℝ).derivative.roots.card ≤
      (cyclotomic (n*q) ℝ).derivative.roots.card) := by
  intro H
  have h : (cyclotomic 885 ℝ).derivative.roots.card ≤
      (cyclotomic 1239 ℝ).derivative.roots.card := H 177 5 7 (by decide) (by
      change Squarefree (3*59 : ℕ)
      exact Nat.squarefree_mul_iff.mpr ⟨by decide, Nat.prime_three.squarefree, (by decide : Nat.Prime 59).squarefree⟩)
      (by decide) (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
  rw [critical885_exact.2.2.1, critical1239_exact.2.2.1] at h
  omega

end Cyclo
