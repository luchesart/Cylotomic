import Cyclo.CertificateChart
import Cyclo.CertificateTransforms
import Cyclo.CertificateNonnegative
import Cyclo.Examples

/-! Sharp bounds and simplicity for the two signed homographic certificates. -/
namespace Cyclo
open Polynomial Set
open Cert Examples

theorem saturate_row {n k : ℕ} {a b : ℝ} (hk : k ≤ signedRootCount n a b)
    (hc : RootCap (Ioo a b) (cyclotomic n ℝ).derivative.eval k ∧
      (∀ T : Finset ℝ,
        (∀ x ∈ T, x ∈ Ioo a b ∧ (cyclotomic n ℝ).derivative.eval x = 0) →
        T.card = k → ∀ x ∈ Ioo a b, (cyclotomic n ℝ).derivative.eval x = 0 →
          (cyclotomic n ℝ).derivative.rootMultiplicity x = 1)) :
    RootCap (Ioo a b) (cyclotomic n ℝ).derivative.eval k ∧
      ∀ x ∈ Ioo a b, (cyclotomic n ℝ).derivative.eval x = 0 →
        (cyclotomic n ℝ).derivative.rootMultiplicity x = 1 := by
  classical
  let T := (cyclotomic n ℝ).derivative.roots.toFinset.filter (· ∈ Ioo a b)
  have hT : ∀ x ∈ T, x ∈ Ioo a b ∧ (cyclotomic n ℝ).derivative.eval x = 0 := by
    intro x hx
    obtain ⟨hz, he⟩ := Finset.mem_filter.mp hx
    exact ⟨he, Polynomial.isRoot_of_mem_roots (Multiset.mem_toFinset.mp hz)⟩
  have card : T.card = k := le_antisymm (hc.1 T hT) hk
  exact ⟨hc.1, hc.2 T hT card⟩

private theorem row_885_neg : RootCap (Ioo (-1 : ℝ) 0) (cyclotomic 885 ℝ).derivative.eval 5 ∧
    ∀ x ∈ Ioo (-1 : ℝ) 0, (cyclotomic 885 ℝ).derivative.eval x = 0 →
      (cyclotomic 885 ℝ).derivative.rootMultiplicity x = 1 := by
  apply saturate_row critical885_lower_counts.1
  have H := chart_certificate (cyclotomic 885 ℝ).derivative (-1) (by norm_num) Q_885_neg
    463 (-1) 202 [421,436,459,463]
    (fun t ht => by simpa using Q_885_neg_eval t ht)
    tilted_signs_885_neg.1 tilted_signs_885_neg.2
  simpa [signedUnitInterval, show (-1 : ℝ) ≠ 1 by norm_num] using H

private theorem row_885_pos : RootCap (Ioo (0 : ℝ) 1) (cyclotomic 885 ℝ).derivative.eval 2 ∧
    ∀ x ∈ Ioo (0 : ℝ) 1, (cyclotomic 885 ℝ).derivative.eval x = 0 →
      (cyclotomic 885 ℝ).derivative.rootMultiplicity x = 1 := by
  apply saturate_row critical885_lower_counts.2
  have H := chart_certificate (cyclotomic 885 ℝ).derivative 1 (by norm_num) Q_885_pos
    463 1 311 [463]
    (fun t ht => by simpa using Q_885_pos_eval t ht)
    tilted_signs_885_pos.1 tilted_signs_885_pos.2
  simpa [signedUnitInterval, show (-1 : ℝ) ≠ 1 by norm_num] using H

private theorem row_1239_neg : RootCap (Ioo (-1 : ℝ) 0) (cyclotomic 1239 ℝ).derivative.eval 3 ∧
    ∀ x ∈ Ioo (-1 : ℝ) 0, (cyclotomic 1239 ℝ).derivative.eval x = 0 →
      (cyclotomic 1239 ℝ).derivative.rootMultiplicity x = 1 := by
  apply saturate_row critical1239_lower_counts.1
  have H := chart_certificate (cyclotomic 1239 ℝ).derivative (-1) (by norm_num) Q_1239_neg
    695 (-1) 328 [687,695]
    (fun t ht => by simpa using Q_1239_neg_eval t ht)
    tilted_signs_1239_neg.1 tilted_signs_1239_neg.2
  simpa [signedUnitInterval, show (-1 : ℝ) ≠ 1 by norm_num] using H

private theorem row_1239_pos : RootCap (Ioo (0 : ℝ) 1) (cyclotomic 1239 ℝ).derivative.eval 2 ∧
    ∀ x ∈ Ioo (0 : ℝ) 1, (cyclotomic 1239 ℝ).derivative.eval x = 0 →
      (cyclotomic 1239 ℝ).derivative.rootMultiplicity x = 1 := by
  apply saturate_row critical1239_lower_counts.2
  have H := chart_certificate (cyclotomic 1239 ℝ).derivative 1 (by norm_num) Q_1239_pos
    695 1 504 [693]
    (fun t ht => by simpa using Q_1239_pos_eval t ht)
    tilted_signs_1239_pos.1 tilted_signs_1239_pos.2
  simpa [signedUnitInterval, show (-1 : ℝ) ≠ 1 by norm_num] using H

theorem case885_upper : RootCap (Ioo (-1 : ℝ) 0) (cyclotomic 885 ℝ).derivative.eval 5 ∧
    RootCap (Ioo (0 : ℝ) 1) (cyclotomic 885 ℝ).derivative.eval 2 :=
  ⟨row_885_neg.1, row_885_pos.1⟩

theorem case885_simple (x : ℝ) (hx : x ∈ Ioo (-1 : ℝ) 0 ∪ Ioo 0 1)
    (hz : (cyclotomic 885 ℝ).derivative.eval x = 0) :
    (cyclotomic 885 ℝ).derivative.rootMultiplicity x = 1 :=
  hx.elim (fun h => row_885_neg.2 x h hz) (fun h => row_885_pos.2 x h hz)

theorem case1239_upper : RootCap (Ioo (-1 : ℝ) 0) (cyclotomic 1239 ℝ).derivative.eval 3 ∧
    RootCap (Ioo (0 : ℝ) 1) (cyclotomic 1239 ℝ).derivative.eval 2 :=
  ⟨row_1239_neg.1, row_1239_pos.1⟩

theorem case1239_simple (x : ℝ) (hx : x ∈ Ioo (-1 : ℝ) 0 ∪ Ioo 0 1)
    (hz : (cyclotomic 1239 ℝ).derivative.eval x = 0) :
    (cyclotomic 1239 ℝ).derivative.rootMultiplicity x = 1 :=
  hx.elim (fun h => row_1239_neg.2 x h hz) (fun h => row_1239_pos.2 x h hz)

end Cyclo
