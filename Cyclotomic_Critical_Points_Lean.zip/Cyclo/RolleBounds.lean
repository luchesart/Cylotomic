import Mathlib.Analysis.Calculus.LocalExtr.Rolle
import Mathlib.Data.Finset.Max
import Mathlib.Data.Set.Finite.Basic

/-! Counting distinct zeros on a real interval by Rolle's theorem. At saturation
none of the zeros can also be a zero of the derivative. -/
namespace Cyclo
open Set Finset

/-- Bound all finite subsets of the zero set in the chosen domain. -/
def RootCap (I : Set ℝ) (f : ℝ → ℝ) (k : ℕ) : Prop :=
  ∀ s : Finset ℝ, (∀ x ∈ s, x ∈ I ∧ f x = 0) → s.card ≤ k

private theorem rootCap_finset {I : Set ℝ} {f : ℝ → ℝ} {k : ℕ}
    (cap : RootCap I f k) :
    ∃ t : Finset ℝ, (∀ x, x ∈ t ↔ x ∈ I ∧ f x = 0) ∧ t.card ≤ k := by
  classical
  let Z : Set ℝ := {x | x ∈ I ∧ f x = 0}
  have hZ : Z.Finite := by
    by_contra hinf
    obtain ⟨s, hs, hk⟩ := Set.Infinite.exists_subset_card_eq hinf (k+1)
    have hb := cap s (fun x hx => hs hx)
    omega
  refine ⟨hZ.toFinset, fun x => hZ.mem_toFinset, ?_⟩
  exact cap _ (fun _ hx => hZ.mem_toFinset.mp hx)

/-- Rolle's theorem counts critical points between successive listed roots.
Those intermediate points are distinct from all listed roots. -/
theorem rolle_interleaves {I : Set ℝ} (hi : I.OrdConnected) {f : ℝ → ℝ}
    (hc : ContinuousOn f I) {s t : Finset ℝ}
    (hs : ∀ x ∈ s, x ∈ I ∧ f x = 0)
    (ht : ∀ x, x ∈ I → deriv f x = 0 → x ∈ t) :
    s.card ≤ (t \ s).card + 1 := by
  classical
  refine Finset.card_le_diff_of_interleaved ?_
  intro x hx y hy hxy _
  have hx' := hs x hx
  have hy' := hs y hy
  have sub := hi.out' hx'.1 hy'.1
  obtain ⟨z, hz, heq⟩ := exists_deriv_eq_zero hxy (hc.mono sub) (hx'.2.trans hy'.2.symm)
  exact ⟨z, ht z (sub ⟨hz.1.le, hz.2.le⟩) heq, hz⟩

/-- An upper bound on the number of critical points gives an upper bound
on the number of roots in any real interval. -/
theorem rolle_count {I : Set ℝ} (hi : I.OrdConnected) {f : ℝ → ℝ}
    (hc : ContinuousOn f I) {k : ℕ} (cap : RootCap I (deriv f) k) :
    RootCap I f (k + 1) := by
  classical
  obtain ⟨t, ht, htk⟩ := rootCap_finset cap
  intro s hs
  have hb := rolle_interleaves hi hc hs (fun x hx hd => (ht x).mpr ⟨hx, hd⟩)
  have hm : (t \ s).card ≤ t.card := Finset.card_le_card Finset.sdiff_subset
  omega

/-- When a finite set of zeros attains Rolle's upper bound, the derivative
is nonzero at every zero in the interval. -/
theorem rolle_simple {I : Set ℝ} (hi : I.OrdConnected) {f : ℝ → ℝ}
    (hc : ContinuousOn f I) {k : ℕ} (cap : RootCap I (deriv f) k)
    {s : Finset ℝ} (hs : ∀ x ∈ s, x ∈ I ∧ f x = 0) (hk : s.card = k + 1)
    {x : ℝ} (hx : x ∈ I) (hf : f x = 0) : deriv f x ≠ 0 := by
  classical
  obtain ⟨t, ht, htk⟩ := rootCap_finset cap
  have hxs : x ∈ s := by
    by_contra hn
    have hb := rolle_count hi hc cap (insert x s) (by
      intro y hy
      rcases Finset.mem_insert.mp hy with rfl | hys
      · exact ⟨hx,hf⟩
      · exact hs y hys)
    rw [Finset.card_insert_of_not_mem hn] at hb
    omega
  intro hd
  have hb := rolle_interleaves hi hc hs (fun z hz hd => (ht z).mpr ⟨hz, hd⟩)
  have hxt : x ∈ t := (ht x).mpr ⟨hx,hd⟩
  have hpos : 0 < (t ∩ s).card :=
    Finset.card_pos.mpr ⟨x, Finset.mem_inter.mpr ⟨hxt,hxs⟩⟩
  have hsum := Finset.card_sdiff_add_card_inter t s
  omega

end Cyclo
