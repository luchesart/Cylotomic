import Cyclo
import Lean.Util.CollectAxioms
import Lean.Elab.Command

/-! Audit every public theorem of the companion, including its transitive dependencies.
An unexpected axiom or an empty theorem inventory makes this file fail. -/
open Lean Elab Command in
run_cmd do
  let env ← getEnv
  let mut names : Array Name := #[]
  for (n, info) in env.constants.toList do
    if (`Cyclo).isPrefixOf n && !n.isInternal && info.isTheorem then
      names := names.push n
  if names.isEmpty then throwError "No project theorems found"
  let allowed : Array Name := #[``propext, ``Classical.choice, ``Quot.sound]
  let sortedNames := names.qsort Name.quickLt
  -- Traverse shared mathlib dependencies once to check the union of all axioms.
  let (_, state) := ((sortedNames.forM Lean.CollectAxioms.collect).run env).run {}
  let unexpected := state.axioms.filter (!allowed.contains ·)
  unless unexpected.isEmpty do throwError "Unexpected project axioms: {unexpected}"
  for n in sortedNames do
    IO.println s!"{n}"
  IO.println s!"Transitive axioms of the complete project: {String.intercalate ", " ((state.axioms.toList.map toString).mergeSort)}"
  IO.println s!"Checked {names.size} public theorems. All transitive axioms are in the standard allowlist."

-- Individual dependency reports for the eight numbered statements and the exact examples.
#print axioms Cyclo.signed_lower_bounds
#print axioms Cyclo.card_real_roots_lower_bound
#print axioms Cyclo.slope_prime_list
#print axioms Cyclo.slope_order_eq_rootMultiplicity
#print axioms Cyclo.integral_iterDelta_eq_zero
#print axioms Cyclo.sign_changes_of_orthogonality
#print axioms Cyclo.kernelNeg_integrable_moment
#print axioms Cyclo.kernelPos_diff_integrable_moment
#print axioms Cyclo.Binary.binary_exact
#print axioms Cyclo.Lifts.prime_power_family
#print axioms Cyclo.critical885_exact
#print axioms Cyclo.critical1239_exact
#print axioms Cyclo.heaney_monotonicity_failure
